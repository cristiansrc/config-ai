# Agentes y Modelos Gemini CLI

Ultima actualizacion: 2026-05-22

Fuente activa:
- Agentes: `/home/cristiansrc/Documentos/config-ai/gemini/agents/`
- Skills: `/home/cristiansrc/Documentos/config-ai/gemini/skills/`
- Backup: `/home/cristiansrc/Documentos/config-ai/gemini/backups/`

| Agente | Modelo | Editar | Bash | Descripcion |
|---|---|---:|---:|---|
| commander (DEFAULT) | google/gemma-4-e4b | allow | allow | Agente principal para gestion del sistema operativo, terminal y tareas diarias. |
| architect-executor | gemma-4-12b-it | allow | allow | Arquitectura y ejecucion compleja. |
| context-curator | google/gemma-4-e4b | deny | deny | Curacion de contexto eficiente. |
| documentation | google/gemma-4-e4b | allow | deny | Generacion de documentacion. |
| executor | google/gemma-4-e4b | allow | allow | Implementacion de codigo. |
| final-validation | gemma-4-12b-it | deny | allow | Validacion final de calidad. |
| planner | gemma-4-12b-it | allow | deny | Planificacion y specs SDD. |
| refactor | gemma-4-12b-it | allow | allow | Refactorizacion de codigo. |
| requirements-analyst | gemma-4-12b-it | allow | deny | Analisis de requerimientos iniciales. |
| reviewer | gemma-4-12b-it | deny | allow | Revision de codigo y calidad. |
| security-reviewer | gemma-4-12b-it | deny | allow | Auditoria de seguridad. |
| spec-remediator | google/gemma-4-e4b | allow | deny | Correccion automatica de specs. |
| spec-validator | gemma-4-12b-it | allow | deny | Validacion de specs SDD. |
| task-decomposer | google/gemma-4-e4b | allow | deny | Descomposicion de tareas. |
| test-architect | google/gemma-4-e4b | allow | allow | Diseno de pruebas automatizadas. |
| functional-test-planner | gemma-4-12b-it | allow | deny | Analisis de specs y diseno de planes de pruebas funcionales. |
| functional-tester-agent | gemma-4-12b-it | allow | allow | Diseno, ejecucion y validacion de pruebas funcionales y UI/E2E en frontends. |
