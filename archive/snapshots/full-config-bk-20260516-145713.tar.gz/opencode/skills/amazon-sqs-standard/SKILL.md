---
name: amazon-sqs-standard
description: Mejores prácticas para Amazon SQS (Visibility Timeout, DLQ, Batching, FIFO).
---

# Estándar Amazon SQS

Guía para el uso eficiente de Amazon SQS como servicio de mensajería gestionado en AWS, dentro de Arquitectura Hexagonal.

## Detección

- Si se detectan dependencias como `spring-cloud-aws-starter-sqs`, `aws-sdk-java` (v2), `boto3` (Python) con configuración de SQS, o ARN de colas SQS, este skill se considera **ACTIVO**.

## Arquitectura Hexagonal

- SQS es un **adaptador de infraestructura** (puerto de salida para publicación, puerto de entrada para consumo).
- La lógica de negocio nunca depende directamente de SQS; depende de interfaces/puertos abstractos.
- Los mensajes entrantes se deserializan en el adaptador antes de pasar al caso de uso. Los mensajes salientes se construyen en el adaptador a partir de eventos del dominio.

## Configuración de Colas

1. **Standard vs FIFO**: Usar colas FIFO solo cuando el orden exacto y la deduplicación estricta sean críticos. Para la mayoría de los casos, preferir Standard por su throughput ilimitado.
2. **FIFO Queue Naming**: Las colas FIFO DEBEN terminar con el sufijo `.fifo` (requerido por AWS).
3. **Visibility Timeout**: Configurar el timeout para que sea al menos **6 veces** el tiempo que tarda el consumidor en procesar el mensaje. Calcular basado en el percentil 99 del tiempo de procesamiento.
4. **Dead Letter Queues (DLQ)**: Configurar siempre una DLQ con un `maxReceiveCount` entre 3 y 5 antes de mover el mensaje a la cola de fallos. La DLQ debe ser del mismo tipo (Standard o FIFO) que la cola original.

## Optimización de Costos y Rendimiento

- **Long Polling**: Configurar `ReceiveMessageWaitTimeSeconds` a **20 segundos** para reducir peticiones vacías y ahorrar costos. Prohibido short polling en producción.
- **Batching**: Usar `SendMessageBatch` y `DeleteMessageBatch` para procesar hasta 10 mensajes por petición, optimizando throughput y costos.
- **Message Retention**: Configurar el tiempo de retención (default 4 días, máximo 14 días) según la criticidad del negocio.
- **Message Size**: SQS soporta hasta 256 KB por mensaje. Para payloads mayores, usar el patrón de referencia: guardar el payload en S3 y enviar solo la referencia en el mensaje SQS.

## Implementación del Consumidor

- **Idempotencia**: Obligatoria. Usar `MessageDeduplicationId` en colas FIFO o verificar `messageId` en BD/Redis para colas Standard.
- **Delete After Process**: Asegurar que el mensaje se elimine de la cola solo después de un procesamiento exitoso y la persistencia local hayan completado.
- **Backoff**: Implementar lógica de reintento con retraso progresivo si el consumidor falla.
- **Graceful Shutdown**: El consumidor debe completar el procesamiento del mensaje actual antes de apagarse, devolviendo el mensaje a la cola si no se completó.

## Seguridad y Trazabilidad

- **Encryption**: Habilitar SSE (Server-Side Encryption) usando claves KMS. Prohibido colas sin cifrado en producción.
- **IAM Roles**: Usar roles con permisos mínimos necesarios (`sqs:SendMessage`, `sqs:ReceiveMessage`, `sqs:DeleteMessage`). Prohibido usar credenciales root o roles excesivamente permisos.
- **Tracing**: Incluir `trace_id` en el atributo `MessageAttribute` del mensaje para trazabilidad distribuida, alineado con el campo `trace_id` del error response estándar del stack activo. Integrar con AWS X-Ray o OpenTelemetry.
- **VPC Endpoints**: Usar VPC Endpoints para SQS en entornos productivos para evitar tráfico por internet público.

## Estructura del Mensaje

- **Formato**: JSON con estructura consistente: `{"event_type": "...", "event_id": "...", "timestamp": "...", "trace_id": "...", "data": {...}}`.
- **Content Type**: Declarar `contentType` en los atributos del mensaje.

## Pruebas

- **Herramientas**: LocalStack o Testcontainers con motox (mock de SQS) para tests de integración.
- **Tests de consumidor**: Verificar idempotencia, manejo de errores, borrado solo tras procesamiento exitoso.
- **Tests de publisher**: Verificar que los mensajes se envían a la cola correcta con los atributos esperados.
- **Tests de DLQ**: Verificar que los mensajes que exceden `maxReceiveCount` se mueven a la DLQ.

## Prohibiciones

- Prohibido short polling en producción (`ReceiveMessageWaitTimeSeconds=0`).
- Prohibido colas sin DLQ configurada para datos de negocio.
- Prohibido colas sin cifrado en producción.
- Prohibido usar credenciales root o roles sobre-permisionados para acceder a SQS.
- Prohibido procesar lógica de negocio directamente en el handler de SQS sin deserializar en un adaptador hexagonal.