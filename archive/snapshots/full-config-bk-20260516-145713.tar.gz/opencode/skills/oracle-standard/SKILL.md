---
name: oracle-standard
description: Estándares y mejores prácticas para el diseño y gestión de bases de datos Oracle.
---

# Estándares Oracle DB

Guía para el desarrollo eficiente sobre Oracle Database, alineada con `flyway-migrations` y `jpa-stack`.

## Detección

- Si el proyecto usa Oracle como motor de base de datos (detectado por dependencias como `ojdbc11`/`ojdbc8` en Maven/Gradle, `oracledb` en Python, o configuración de datasource), este skill se considera **ACTIVO**.

## Naming y Estructura

- **Naming**: `UPPER_SNAKE_CASE` (estándar de Oracle por defecto). Limitar nombres a 30 caracteres para compatibilidad con versiones < 12.2; 128 caracteres en Oracle 12.2+.
- **Prefijos de constraints**: `PK_` para primary keys, `FK_<TABLA_ORIGEN>_<TABLA_DESTINO>` para foreign keys, `UK_<TABLA>_<COLUMNA>` para unique, `CHK_<TABLA>_<CONDICION>` para checks, `IDX_<TABLA>_<COLUMNA>` para índices.
- **Schemas**: En Oracle, un `USER` es equivalente a un `SCHEMA`. Usar schemas para agrupar por dominio.
- **Tablespaces**: Definir tablespaces específicos para datos e índices para optimizar I/O.

## Tipos de Datos

- **IDs**: Usar `GENERATED ALWAYS AS IDENTITY` (Oracle 12c+). Para IDs descentralizados, usar `RAW(16)` con `SYS_GUID()` o `VARCHAR2(36)` para UUIDs.
- **Numbers**: Usar `NUMBER` para todo valor numérico. `NUMBER(19,0)` para IDs largos, `NUMBER(1,0)` para booleanos.
- **Strings**: Usar `VARCHAR2(n CHAR)` para asegurar que el límite es en caracteres, no en bytes. Prohibido `VARCHAR2(n BYTE)` para datos de negocio.
- **Booleans**: Usar `NUMBER(1,0)` con restricción `CHECK (column IN (0,1))`.
- **LOBs**: Usar `CLOB` para textos largos y `BLOB` para binarios. Prohibido `LONG`.
- **Dates**: Usar `TIMESTAMP WITH TIME ZONE` para timestamps de negocio. Prohibido `DATE` para datos que requieren zona horaria.

## Índices y Rendimiento

- **Indexes**: Oracle usa B-Tree por defecto. Considerar `Bitmap Indexes` solo para columnas con baja cardinalidad en entornos de Data Warehouse.
- **Sequences**: Usar `CACHE` en secuencias para mejorar rendimiento de inserción masiva (ej: `CACHE 100`).
- **Execution Plan**: Usar `EXPLAIN PLAN FOR` seguido de `DBMS_XPLAN.DISPLAY`.

## Integridad

- **Foreign Keys**: Definir siempre con nombres explícitos. Por defecto `ON DELETE RESTRICT`; usar `ON DELETE CASCADE` solo cuando sea explícitamente requerido por el dominio.
- **Constraints**: Definir `NOT NULL` y `CHECK` donde aplique. Oracle soporta constraints en estado `ENABLE VALIDATE` y `ENABLE NOVALIDATE` para migraciones.

## Auditoría y Soft Delete

Obligatorio en toda tabla de negocio, alineado con `jpa-stack`:

- **Campos de Auditoría**:
    - `CREATED_AT TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT SYSTIMESTAMP`
    - `UPDATED_AT TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT SYSTIMESTAMP`
- **Soft Delete**:
    - `DELETED NUMBER(1,0) DEFAULT 0 NOT NULL CHECK (DELETED IN (0,1))`
    - Índice parcial: `CREATE INDEX IDX_<TABLA>_ACTIVE ON <TABLA>(ID) WHERE DELETED = 0;` (requiere Oracle 12c+ con function-based index si filtering no aplica).
- **Trigger de Actualización**:
    ```sql
    CREATE OR REPLACE TRIGGER TRG_<TABLA>_UPD
    BEFORE UPDATE ON <TABLA>
    FOR EACH ROW
    BEGIN
        :NEW.UPDATED_AT := SYSTIMESTAMP;
    END;
    ```
- **Prohibido** usar `DELETE` físico en tablas de negocio. Usar `UPDATE SET DELETED = 1` en su lugar.

## Paginación

- Usar `OFFSET / FETCH` (Oracle 12c+). Prohibido `ROWNUM` anidado para paginación nueva.

## Prohibiciones

- Prohibido `LONG`. Usar `CLOB`.
- Prohibido `VARCHAR2(n BYTE)` para datos de negocio.
- Prohibido `DATE` para datos que requieren zona horaria.
- Prohibido `DELETE` físico en tablas de negocio.
- Prohibido crear tablas sin campos de auditoría y soft delete.
- Prohibido `ROWNUM` anidado para paginación nueva; usar `OFFSET/FETCH`.