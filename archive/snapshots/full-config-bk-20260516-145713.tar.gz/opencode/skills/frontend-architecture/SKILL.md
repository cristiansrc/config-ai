---
name: frontend-architecture
description: Arquitectura limpia para React y Angular. Principios transversales de estructura, estado, API y testing.
---

# Estándares de Arquitectura Frontend

Principios arquitectónicos transversales para aplicaciones React y Angular. Para detalles específicos de cada framework, ver `react-stack` o `angular-stack`.

## Detección

- Si el proyecto contiene `package.json` con dependencias de `react` o `@angular/core`, este skill se considera **ACTIVO** junto con la skill específica del framework.

## Principios Comunes

### Feature-Sliced Design (FSD)
- Organizar la aplicación en capas horizontales: `app` → `pages` → `features` → `entities` → `shared`.
- Cada capa solo puede importar de capas inferiores. **Prohibido** importar de capas superiores.
- Los `features` encapsulan lógica de negocio agrupada por caso de uso. Los `entities` contienen modelos de dominio y lógica de negocio pura sin UI.

### Separación de Responsabilidades
- **Presentación**: Componentes visuales sin lógica de negocio (solo render y eventos).
- **Lógica de Negocio**: Hooks (React) o Services (Angular) con la lógica de aplicación.
- **Infraestructura**: Clientes de API, adaptadores de estado, interceptores.

### Type Safety
- Uso obligatorio de TypeScript strict mode.
- Tipado explícito de Props, estados, respuestas de API y eventos.
- Prohibido `any`. Usar `unknown` cuando el tipo es desconocido y narrow con type guards.

### Gestión de Estado
- **Server State**: Usar TanStack Query (React) o Signal-based Data Services (Angular) para datos del servidor. Prohibido almacenar datos de API en estado global de cliente.
- **Client State**: Usar Zustand (React) o Signals (Angular) para estado UI y global ligero.
- **URL State**: Usar los parámetros de ruta como fuente de verdad para filtros, paginación y tabs activos.

### Clientes de API
- Aislamiento de la configuración de red en clientes dedicados.
- Centralización del manejo de errores HTTP y transformaciones de datos.
- Sincronización obligatoria con el contrato OpenAPI del proyecto (ver `openapi-first` y `openapi-standard`).
- Los errores HTTP deben mapearse al schema de error response estándar del backend (`trace_id`, `status`, `error`, `code`, `message`, `path`, `details`).

### Testing
- Archivos de test junto al componente que prueban (colocation).
- **Unit**: Componentes, hooks, services con Vitest (React) o Jest (Angular).
- **Integration**: Flujos completos de usuario con Testing Library.
- **E2E**: Playwright o Cypress para flujos críticos.
- Cobertura mínima: **85%** por archivo testable, excluyendo DTOs, interfaces puras y configs.

### Auth y Seguridad
- Tokens JWT almacenados en HttpOnly cookies cuando sea posible. Si no, en memory (no en localStorage).
- Rutas protegidas mediante guards/ProtectedRoute components que redirigen al login.
- Verificar permisos en el frontend solo para UX (ocultar/mostrar); la autorización real siempre es en el backend.
- Ver `keycloak-standard` y `security-standards` para detalles.

## Prohibiciones

- Prohibido importar de capas superiores en FSD.
- Prohibido `any` en TypeScript. Usar `unknown` con type guards.
- Prohibido almacenar datos de API en estado global de cliente.
- Prohibido tokens JWT en `localStorage`. Usar HttpOnly cookies o memory.