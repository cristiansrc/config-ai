---
name: git-ops
description: Gestión profesional del ciclo de vida de Git y GitHub. Ramas, commits semánticos y Pull Requests.
---

# Git Ops Skill

Gestión del flujo de trabajo de Git de forma autónoma y profesional, asegurando consistencia en los mensajes de commit y la estructura del repositorio.

## Detección

- Si el proyecto tiene un repositorio Git inicializado, este skill se considera **ACTIVO** para todas las operaciones de control de versiones.

## Convenciones de Ramas (Branching)

- **Formato**: `tipo/descripcion-breve`
- **Tipos**:
    - `feature/`: Nuevas funcionalidades o mejoras.
    - `fix/`: Corrección de errores.
    - `docs/`: Cambios solo en documentación.
    - `refactor/`: Cambios en el código sin añadir funcionalidad ni corregir errores.
    - `chore/`: Tareas de mantenimiento (actualización de dependencias, configs).
- **Prohibido** hacer commit directo en `main`/`master` para cambios de código. Todo cambio debe pasar por una rama feature y PR.

## Mensajes de Commit (Conventional Commits)

- **Formato**: `tipo(scope): descripcion`
- **Tipos**: `feat`, `fix`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`, `chore`.
- **Scope**: El módulo o capa afectada (ej: `api`, `auth`, `ui`, `db`).
- **Descripción**: En minúsculas, tiempo presente, máximo 50 caracteres.
- **Ejemplo**: `feat(auth): implement JWT token rotation`

## Flujo de Trabajo Operativo

### Paso A: Verificación (Pre-commit)
Nunca realizar un commit si el código no ha sido verificado.
1. Ejecutar tests relevantes con el gestor del stack: `pnpm test`, `mvn test`, `pytest`, etc.
2. Ejecutar linter/formatter: `pnpm run lint`, `ruff check`, etc.
3. En proyectos JavaScript/TypeScript, prohibido `npm`. Usar `pnpm` obligatoriamente. Si existe `package-lock.json`, detenerse y proponer migración a `pnpm-lock.yaml`.

### Paso B: Preparación de Cambios
1. Identificar archivos modificados relacionados estrictamente con la tarea.
2. Hacer `git add` de archivos específicos. Prohibido `git add .` si hay cambios no relacionados.

### Paso C: Commit Semántico
Generar el mensaje basado en el análisis de los cambios. Si hay dudas sobre el scope, usar el nombre del directorio principal afectado.

### Paso D: Publicación y PR (GitHub)
1. `git push origin <branch-name>`.
2. Crear PR con título descriptivo y cuerpo que incluya resumen de cambios.
3. Mencionar issues cerrados (ej: `Closes #123`).

## Integración con SDD

- **Planner/Task Decomposer**: Indican si la tarea requiere una nueva rama.
- **Executor**: Realiza commits atómicos por cada tarea completada del desglose.
- **Final Validation**: Confirma que el PR ha sido creado correctamente.

## Prohibiciones

- Prohibido commit directo en `main`/`master` para cambios de código.
- Prohibido `git add .` cuando hay cambios no relacionados.
- Prohibido `npm` en proyectos JavaScript/TypeScript. Usar `pnpm`.
- Prohibido commits sin verificación previa (tests + lint).