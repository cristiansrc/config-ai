---
name: angular-stack
description: Convenciones de Angular 2026 (Standalone, Signals, Zoneless) y sincronización de OpenAPI.
---

# Estándares Angular

Convenciones de rutas, arquitectura y patrones para proyectos Angular modernos (2026).

## Detección

- Si el archivo `angular.json` existe o `package.json` contiene `@angular/core`, este skill se considera **ACTIVO**.

## Estructura de Carpetas

- **Core API**: `src/app/core/api/` (Cliente base y OpenAPI sincronizado).
- **Features**: `src/app/features/` (Módulos funcionales y componentes standalone).
- **Shared**: `src/app/shared/` (Componentes UI, pipes y directivas reutilizables).
- **Domain/Models**: `src/app/core/models/` (Interfaces y tipos de dominio).
- **Core/Services**: `src/app/core/services/` (Servicios inyectables de infraestructura).

## Arquitectura y Componentes

- **Standalone Components**: Todos los componentes, directivas y pipes deben usar `standalone: true`. Prohibido NgModules para nuevos desarrollos.
- **Signals**: Usar Angular Signals (`signal`, `computed`, `input`, `output`, `effect`) para gestión de estado y reactividad. Prohibido RxJS para estado local síncrono.
- **RxJS**: Usar Observable/Subject solo para flujos asíncronos complejos (WebSockets, eventos de teclado, streams reactivos). Preferir `toSignal()` para convertir Observables a Signals en componentes.
- **Zoneless**: Evitar la dependencia de `zone.js`. Usar `provideZonelessChangeDetection()` en nuevas aplicaciones.
- **Lazy Loading**: Cargar features con `loadComponent` y `loadChildren` en las rutas.

## Gestión de Estado

- **Server State**: Usar señales basadas en servicios de datos para datos del servidor. Prohibido almacenar datos de API en services de estado global síncrono.
- **Client State**: Usar Signals para estado UI y global ligero.
- **URL State**: Usar Router params y QueryParams como fuente de verdad para filtros, paginación y tabs activos.

## Convenciones de Archivos

- **Componentes**: `_<nombre>.component.ts` con template inline para componentes pequeños, archivo `.html` separado para templates complejos.
- **Servicios**: `<nombre>.service.ts` con `providedIn: 'root'`.
- **Tests**: Junto al componente con extensión `.spec.ts` (colocation).
- **OpenAPI Runtime**: `src/app/core/api/openapi.yaml` (sincronizado desde `docs/api/openapi.yaml`).

## Inyección de Dependencias

- Usar `inject()` en lugar de constructor injection para nuevos desarrollos.
- Servicios con `providedIn: 'root'` por defecto (singleton).
- Prohibido provisión de servicios en módulos o componentes para servicios shared.

## API y Errores

- Cliente de API centralizado en `src/app/core/api/` con `HttpInterceptor` para manejo global de errores y auth.
- Los errores HTTP deben mapearse al schema de error response del backend (`trace_id`, `status`, `error`, `code`, `message`, `path`, `details`).
- Sincronización obligatoria con el contrato OpenAPI (ver `openapi-first` y `openapi-standard`).

## Pruebas y Cobertura

- **Herramientas**: Jest + Angular Testing Utilities + Playwright (E2E).
- **Unit**: Componentes, services, pipes y directivas.
- **Integration**: Flujos de usuario con Testing Library o Component Harnesses.
- **E2E**: Playwright para flujos críticos.
- **Cobertura**: Mínimo 85% por archivo testable. Excluir interfaces puras, enums y configs.

## Comportamiento Obligatorio

1. El agente Executor debe asegurar que `docs/api/openapi.yaml` se copie a `src/app/core/api/openapi.yaml` si hay cambios.
2. Todos los componentes nuevos deben ser standalone.
3. TypeScript strict mode en `tsconfig.json`.

## Prohibiciones

- Prohibido NgModules para nuevos desarrollos.
- Prohibido `any` en TypeScript.
- Prohibido almacenar datos de API en services de estado global síncrono.
- Prohibido lógica de negocio en componentes de presentación.
- Prohibido `zone.js` para nuevas aplicaciones.