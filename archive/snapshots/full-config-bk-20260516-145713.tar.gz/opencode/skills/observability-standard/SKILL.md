---
name: observability-standard
description: Estándares de monitoreo, logs JSON, métricas y trazabilidad con OpenTelemetry.
---

# Estándar de Observabilidad

Estándares de monitoreo, logs y trazabilidad para asegurar que todos los servicios sean "visibles" en producción.

## Detección

- Si el proyecto está destinado a producción o staging, este skill se considera **ACTIVO** para todos los servicios backend.

## Estándares de Logs

- **Formato**: JSON obligatorio para facilitar parsing por herramientas como ELK, Grafana Loki o CloudWatch.
- **Campos Obligatorios**: `timestamp`, `level`, `service_name`, `trace_id`, `span_id`, `message`, `path`, `user_id` (si aplica).
- **Niveles**:
    - `DEBUG`: Información detallada para desarrollo. Prohibido en producción excepto para troubleshooting activo.
    - `INFO`: Hitos importantes del negocio (inicio de servicio, operaciones significativas).
    - `WARN`: Problemas recuperables que merecen atención.
    - `ERROR`: Fallos que requieren atención inmediata. Incluir `trace_id` para correlación.
- **Prohibido**: Loguear secretos, contraseñas, tokens, o datos PII (Personally Identifiable Information).

## Trazabilidad Distribuida

- **OpenTelemetry**: Uso obligatorio de OTel para propagación de contexto (`traceparent` header).
- **Trace ID**: Usar `X-Trace-Id` como header canónico en HTTP y `trace_id` en headers de mensajería (ver `rabbitmq-standard`, `kafka-standard`, `amazon-sqs-standard`).
- **Correlación**: El `trace_id` en logs debe coincidir con el `trace_id` en el error response del stack activo (ver skills de error response).

## Métricas Críticas

Todos los servicios deben exponer:
- **Latencia**: Percentiles p50, p95, p99 de peticiones.
- **Tasa de errores**: Errores por minuto, categorizados por tipo (4xx, 5xx).
- **Saturación**: Uso de CPU y RAM.
- **Throughput**: Peticiones por segundo.
- **Health Checks**: Endpoints `/health/live` (liveness) y `/health/ready` (readiness).

## Instrumentación por Stack

- **Spring Boot**: Micrometer + OpenTelemetry Java Agent. Exponer métricas en `/actuator/prometheus`.
- **FastAPI**: Prometheus Client + OpenTelemetry Python. Middleware de tracing automático.
- **Node.js**: OpenTelemetry SDK + Prometheus client.

## Comportamiento Obligatorio

1. El agente Executor debe incluir interceptores o middlewares de logging en cada punto de entrada (API, Workers, Consumers).
2. Los logs NO deben contener secretos, contraseñas ni datos PII.
3. Todo servicio debe exponer health checks y métricas de Prometheus.

## Prohibiciones

- Prohibido logs en texto plano en producción (usar JSON).
- Prohibido loguear secretos, contraseñas, tokens o datos PII.
- Prohibido `DEBUG` en producción excepto para troubleshooting activo.
- Prohibido servicios sin health checks en producción.