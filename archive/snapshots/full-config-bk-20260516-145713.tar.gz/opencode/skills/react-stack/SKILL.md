---
name: react-stack
description: Convenciones de React 2026 (FSD, TanStack Query, Zustand, React 19) y sincronización de OpenAPI.
---

# Estándares React

Convenciones de rutas, arquitectura y patrones para proyectos React modernos (2026).

## Detección

- Si el archivo `package.json` contiene la dependencia `react`, este skill se considera **ACTIVO**.

## Estructura de Carpetas (Feature-Sliced Design)

- **Shared API**: `src/shared/api/` (Cliente base y OpenAPI sincronizado).
- **Features**: `src/features/` (Componentes con lógica de negocio e interacciones).
- **Entities**: `src/entities/` (Modelos de datos, tipos de dominio y lógica de negocio pura).
- **UI Kit**: `src/shared/ui/` (Componentes atómicos/presentacionales sin lógica de negocio).
- **Pages**: `src/pages/` (Composición de componentes a nivel de ruta).

## Gestión de Estado

- **Server State**: Usar obligatoriamente TanStack Query para caché y sincronización de datos del servidor. Prohibido almacenar datos de API en Zustand o useState.
- **Client State**: Usar Zustand para estado global ligero (theme, auth UI state, toasts).
- **URL State**: Usar los parámetros de ruta y search params como fuente de verdad para filtros, paginación y tabs activos.

## Convenciones de Archivos

- **Componentes**: `PascalCase.tsx` para componentes, `kebab-case.ts` para utilidades.
- **Hooks personalizados**: `use-<feature>.ts` en la carpeta del feature.
- **Tests**: Junto al componente con extensión `.test.tsx` (colocation).
- **OpenAPI Runtime**: `src/shared/api/openapi.yaml` (sincronizado desde `docs/api/openapi.yaml`).

## React 19

- Priorizar Server Actions, `useActionState` y `useOptimistic` para gestión de formularios y feedback instantáneo.
- Usar `Suspense` boundaries para manejo declarativo de estados de carga.
- Usar `ErrorBoundary` para manejo declarativo de errores a nivel de feature.

## Type Safety

- TypeScript strict mode obligatorio.
- Tipado estricto para todas las Props, estados y respuestas de API.
- Prohibido `any`. Usar `unknown` con type guards cuando el tipo es desconocido.

## API y Errores

- Cliente de API centralizado en `src/shared/api/` con manejo global de errores.
- Los errores HTTP deben mapearse al schema de error response del backend (`trace_id`, `status`, `error`, `code`, `message`, `path`, `details`).
- Sincronización obligatoria con el contrato OpenAPI (ver `openapi-first` y `openapi-standard`).

## Pruebas y Cobertura

- **Herramientas**: Vitest + React Testing Library + Playwright (E2E).
- **Unit**: Componentes, hooks y utilidades.
- **Integration**: Flujos de usuario con Testing Library.
- **E2E**: Playwright para flujos críticos.
- **Cobertura**: Mínimo 85% por archivo testable. Excluir DTOs, interfaces puras y configs.

## Comportamiento Obligatorio

1. El agente Executor debe asegurar que `docs/api/openapi.yaml` se copie a `src/shared/api/openapi.yaml` si hay cambios o si el archivo de destino falta.
2. Datos del servidor siempre viajan por TanStack Query, nunca en Zustand.
3. TypeScript strict mode en `tsconfig.json`.

## Prohibiciones

- Prohibido `any` en TypeScript.
- Prohibido almacenar datos de API en Zustand o useState.
- Prohibido lógica de negocio en componentes de presentación.
- Prohibido tokens JWT en `localStorage`.