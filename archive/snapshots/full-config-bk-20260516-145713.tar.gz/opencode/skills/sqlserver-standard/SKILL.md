---
name: sqlserver-standard
description: Estándares y mejores prácticas para el diseño y gestión de bases de datos SQL Server.
---

# Estándares SQL Server (T-SQL)

Guía para el desarrollo eficiente sobre Microsoft SQL Server, alineada con `flyway-migrations` y `jpa-stack`.

## Detección

- Si el proyecto usa SQL Server como motor de base de datos (detectado por dependencias como `mssql-jdbc` en Maven/Gradle, `pyodbc`/`mssql` en Python, o configuración de datasource), este skill se considera **ACTIVO**.

## Naming y Esquemas

- **Naming**: `snake_case` para tablas, columnas, índices y constraints (consistente con el estándar de los otros motores del proyecto). Evitar PascalCase para mantener consistencia con el mapeo ORM.
- **Prefijos de constraints**: `pk_` para primary keys, `fk_<tabla_origen>_<tabla_destino>` para foreign keys, `uk_<tabla>_<columna>` para unique, `chk_<tabla>_<condicion>` para checks, `idx_<tabla>_<columna>` para índices.
- **Schemas**: Usar esquemas para agrupar tablas funcionalmente (ej: `Sales.Orders` en lugar de `dbo.SalesOrders`). Prohibido almacenar todas las tablas en `dbo`.
- **Quotes**: Usar corchetes `[table_name]` solo cuando el identificador contenga espacios o sea palabra reservada. Evitar identificadores que lo requieran.

## Tipos de Datos

- **IDs**: Usar `INT IDENTITY(1,1)` o `BIGINT IDENTITY(1,1)`. Para IDs descentralizados, usar `UNIQUEIDENTIFIER` con `NEWSEQUENTIALID()` o `NEWID()`.
- **Strings**: Usar `NVARCHAR(n)` para soporte Unicode completo. Usar `VARCHAR(n)` solo cuando el ahorro de espacio sea crítico y no se necesite i18n.
- **Booleans**: Usar tipo `BIT` con convención `0/1`.
- **Dates**: Usar `DATETIMEOFFSET` para timestamps de negocio con zona horaria. Prohibido `DATETIME` para nuevos desarrollos.
- **Money**: Prohibido `MONEY`/`SMALLMONEY`. Usar `DECIMAL(p,s)` para valores monetarios.

## Índices y Rendimiento

- **Clustered Index**: Generalmente en la clave primaria. SQL Server ordena físicamente los datos basándose en este índice.
- **Non-Clustered Indexes**: Para optimizar búsquedas frecuentes.
- **Included Columns**: Usar `INCLUDE` en índices no clúster para cubrir queries sin añadir columnas a la estructura del árbol del índice.
- **SARGability**: Escribir queries que permitan el uso de índices. Prohibido aplicar funciones sobre columnas en el `WHERE` que impidan el uso de índices.

## Integridad y Transacciones

- **DDL Transaccional**: SQL Server permite envolver cambios de esquema (CREATE, ALTER) en transacciones.
- **Foreign Keys**: Definir siempre con `ON DELETE NO ACTION` por defecto para evitar cascadas accidentales. Usar `ON DELETE CASCADE` solo cuando sea explícitamente requerido por el dominio.

## Auditoría y Soft Delete

Obligatorio en toda tabla de negocio, alineado con `jpa-stack`:

- **Campos de Auditoría**:
    - `created_at DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()`
    - `updated_at DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()`
- **Soft Delete**:
    - `deleted BIT NOT NULL DEFAULT 0`
    - Índice filtrado obligatorio: `CREATE INDEX idx_<tabla>_active ON <tabla>(id) WHERE deleted = 0;`
- **Trigger de Actualización**: Usar triggers en SQL Server para `updated_at` si JPA/Hibernate no lo gestiona.
- **Prohibido** usar `DELETE` físico en tablas de negocio. Usar `UPDATE SET deleted = 1` en su lugar.

## Prohibiciones

- Prohibido `MONEY`/`SMALLMONEY`. Usar `DECIMAL(p,s)`.
- Prohibido `DATETIME` para nuevos desarrollos. Usar `DATETIMEOFFSET`.
- Prohibido `DELETE` físico en tablas de negocio.
- Prohibido crear tablas sin campos de auditoría y soft delete.
- Prohibido usar `dbo` como schema por defecto para todas las tablas.
- Prohibido `Cursors` excesivos; preferir operaciones basadas en conjuntos (SET-based).

## Mejores Prácticas de T-SQL

- Usar `SET NOCOUNT ON` al inicio de procedimientos almacenados para evitar tráfico de red innecesario.
- Usar `TRY...CATCH` para el manejo de errores en T-SQL.
- Usar `OFFSET / FETCH` para paginación (SQL Server 2012+).
- Monitorear rendimiento con `Query Store` y `Execution Plan` gráfico.