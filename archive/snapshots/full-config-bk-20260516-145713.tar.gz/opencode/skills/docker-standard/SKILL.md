---
name: docker-standard
description: Empaquetamiento seguro (Multi-stage, No root) y docker-compose local.
---

# Estándar Docker

Convenciones para el empaquetamiento y despliegue de aplicaciones con Docker, asegurando seguridad y optimización.

## Detección

- Si el proyecto contiene un `Dockerfile` o `docker-compose.yml`, este skill se considera **ACTIVO**.

## Dockerfiles (Multi-stage)

1. **Build Stage**: Usar una imagen base completa para compilar (ej: `maven`, `node:20`, `python:3.12-slim`).
2. **Run Stage**: Usar una imagen mínima (Distroless o Alpine) para ejecutar. Prohibido imágenes base completas en el stage final.
3. **No Root**: Definir un usuario sin privilegios (`appuser`). Prohibido ejecutar contenedores como root.
    ```dockerfile
    RUN addgroup --system appgroup && adduser --system --ingroup appgroup appuser
    USER appuser
    ```
4. **Layer Caching**: Ordenar instrucciones de menos frecuencia de cambio a más. Copiar dependencias antes que código fuente.
5. **Multi-stage obligatorio**: Prohibido un solo stage para build y runtime cuando el lenguaje lo permite (Java, Node, Go, Python).

## Health Checks

- Todo contenedor debe definir un `HEALTHCHECK` con endpoints `/health/live` (liveness) y `/health/ready` (readiness).
- Spring Boot: Usar Actuator health endpoints.
- FastAPI: Implementar endpoints de health explícitos.
- Node.js: Implementar endpoints de health explícitos.

## Docker Compose

- Debe existir un `docker-compose.yml` en la raíz para levantar dependencias locales (BD, Redis, colas).
- Usar redes internas aisladas y nombres de contenedores descriptivos.
- Variables de entorno no sensibles en `.env`. Secretos via Vault o variables de entorno del host.
- Prohibido hardcodear secretos en `docker-compose.yml`.

## .dockerignore

- El archivo `.dockerignore` debe estar presente y configurado para ignorar:
    - `node_modules`, `target`, `venv`, `.git`
    - Archivos de secretos (`.env`, `*.key`, `*.pem`)
    - Archivos IDE (`.idea`, `.vscode`)
    - `docker-compose.override.yml`

## Image Tagging

- Prohibido usar `latest` como tag de producción.
- Formato de tag: `<version>-<short-sha>` o `<version>-<build-number>`.
- Las imágenes deben incluir etiquetas de metadata: `maintainer`, `version`, `description`.

## Resource Limits

- Definir `memory` y `cpu` limits en producción para prevenir que un contenedor consuma todos los recursos del host.

## Comportamiento Obligatorio

1. El agente Executor debe asegurar que el `.dockerignore` esté presente y configurado.
2. Todo Dockerfile debe ser multi-stage cuando el lenguaje lo permite.
3. Todo contenedor debe ejecutarse como usuario sin privilegios.
4. Los secretos se pasan mediante variables de entorno, nunca hardcodeados en el Dockerfile.

## Prohibiciones

- Prohibido ejecutar contenedores como root.
- Prohibido usar `latest` como tag de producción.
- Prohibido hardcodear secretos en Dockerfile o docker-compose.yml.
- Prohibido imágenes base completas en el stage final de runtime.
- Prohibido ignorar `.dockerignore`.