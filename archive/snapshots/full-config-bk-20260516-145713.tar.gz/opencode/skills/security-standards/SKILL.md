---
name: security-standards
description: Estándares de seguridad para aplicaciones Spring Boot y Frontend. JWT, OAuth2/OIDC, RBAC, prevención de vulnerabilidades y gestión de identidad.
---

# Security Standards

Estándares de seguridad para asegurar que el código generado sea seguro por diseño. Para configuración específica de Keycloak, ver `keycloak-standard`.

## Detección

- Si el proyecto maneja autenticación, autorización, tokens JWT, OAuth2/OIDC o datos sensibles, este skill se considera **ACTIVO** para todos los proyectos.

## Autenticación y Autorización

- **JWT**: Implementar rotación de tokens y validación estricta. Access token lifespan corto (5-15 min). Refresh tokens solo sobre canales seguros.
- **OAuth2/OIDC**: Preferir Authorization Code + PKCE para frontends y Client Credentials para comunicación service-to-service. Prohibido Resource Owner Password Credentials en producción.
- **RBAC**: En Spring Boot, usar `@PreAuthorize` con roles y permisos claros. En FastAPI, usar `Depends` con verificación de roles. Nunca hacer autorización solo en el frontend.
- **Secrets**: Prohibido hardcodear credenciales. Usar variables de entorno o Secret Managers (Vault, AWS Secrets Manager).

## Validación de Tokens

- **Issuer**: Validar siempre contra `issuer-uri`/discovery document del realm.
- **JWKS**: Verificar firma con JWKS remoto. Prohibido aceptar tokens sin `iss`, `aud`, `exp` y `typ` válidos.
- **Audience**: Exigir `aud` o `azp` esperado por la API. Rechazar tokens emitidos para otro client.
- **Roles**: Mapear roles desde `realm_access.roles` o `resource_access.<client>.roles` de forma explícita.
- **Logout**: Implementar logout OIDC y limpieza de sesión/cookies cuando aplique.

## Protección de Datos

- **Validación de Input**: Validar todos los campos de entrada en el servidor. Usar Bean Validation (Java) o Pydantic (Python) para el backend; Zod (TypeScript) para el frontend.
- **Sanitización**: Escapar datos que se mostrarán en el frontend para prevenir XSS.
- **No Exposure**: Prohibido exponer datos sensibles en logs, respuestas de API, URLs o mensajes de error. Filtrar `password`, `token`, `secret`, `apiKey`, `authorization` de los logs.
- **Soft Delete**: Los datos eliminados lógicamente no deben ser accesibles por APIs públicas. Ver la skill de BD correspondiente para la convención de campo `deleted`.

## Configuración de Seguridad

- **CORS**: Configuración restrictiva basada en el entorno. Prohibido `Access-Control-Allow-Origin: *` en producción.
- **Headers de Seguridad**: Implementar HSTS, Content-Security-Policy, X-Content-Type-Options, X-Frame-Options.
- **Rate Limiting**: Implementar rate limiting en APIs públicas. Ver `spring-cloud-gateway` para implementación en Gateway.
- **HTTPS**: Obligatorio en producción. Prohibido HTTP para datos sensibles.

## OWASP Top 10

- Seguir las recomendaciones del OWASP Top 10 como baseline mínimo.
- Los errores de API NO deben exponer stack traces, nombres de tablas, o detalles internos.

## Checklist de Implementación

1. Documentar realm, client IDs, roles, scopes, redirect URIs y audiences en la spec.
2. Crear variables de entorno para issuer, client ID, client secret y audience.
3. Agregar tests para token válido, token expirado, issuer incorrecto, audience incorrecto y rol insuficiente.
4. Verificar que los logs no contienen datos sensibles.
5. Verificar que CORS está configurado restrictivamente.

## Prohibiciones

- Prohibido hardcodear credenciales, tokens o secrets en el código.
- Prohibido `Access-Control-Allow-Origin: *` en producción.
- Prohibido HTTP para datos sensibles.
- Prohibido Resource Owner Password Credentials en producción.
- Prohibido exponer stack traces o detalles internos en respuestas de error.
- Prohibido almacenar tokens JWT en `localStorage`. Usar HttpOnly cookies o memory.