---
name: documentation-lifecycle
description: Gestión del ciclo de vida de la documentación técnica. Consolidación de incrementos en la Master Spec.
---

# Documentation Lifecycle

Asegura que la documentación del proyecto no se degrade con el tiempo, manteniendo la Master Spec como fuente de verdad única.

## Detección

- Si el proyecto tiene una Master Spec (`docs/specs/master_spec.md`) o usa el flujo SDD, este skill se considera **ACTIVO**.

## Gestión de Master Spec

- La `Master Spec` (`docs/specs/master_spec.md`) representa la verdad actual del sistema.
- Es el único documento que refleja el estado actual del software. Documentación dispersa o contradictoria debe consolidarse aquí.

## Flujo de Consolidación

Tras la aprobación de un incremento (Delta Spec):
1. El agente debe integrar los cambios del incremento en la `Master Spec`.
2. Se deben eliminar las secciones obsoletas y actualizar diagramas Mermaid.
3. El incremento aprobado se mueve a `docs/specs/archive/` como referencia inmutable.
4. La Master Spec resultante debe ser coherente: sin secciones duplicadas, sin referencias a artefactos eliminados y sin drift con el código real.

## Sincronización con OpenAPI

- Cualquier cambio en la documentación que afecte contratos debe verse reflejado en la ruta OpenAPI canónica declarada por el proyecto.
- El agente debe validar que las descripciones en el YAML coincidan con las reglas de negocio descritas en la Master Spec.
- **Documentation no edita OpenAPI directamente**. Si detecta drift contractual, lo reporta para que Planner o Executor corrijan.

## Sincronización con Migraciones

- Cambios en la documentación que afecten la estructura de BD deben corroborarse contra los archivos de migración existentes. Ver `flyway-migrations`.
- Prohibido describir tablas o columnas en la Master Spec que no existan en las migraciones, y viceversa.

## Trazabilidad

- Cada cambio estructural en el código debe poder rastrearse hasta una sección de la Master Spec o un ID de incremento.
- La Master Spec debe incluir un registro de cambios (changelog) con referencia al ID del incremento.

## Prohibiciones

- Prohibido editar OpenAPI desde Documentation. Reportar drift al Planner/Executor.
- Prohibido secciones duplicadas o contradictorias en la Master Spec.
- Prohibido describir artefactos en la Master Spec que no existan en el código o las migraciones.