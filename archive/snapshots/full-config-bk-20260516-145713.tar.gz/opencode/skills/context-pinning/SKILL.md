---
name: context-pinning
description: Gestión de archivos críticos para mantener la integridad arquitectónica y el diseño del sistema. Asegura que los agentes siempre lean la Master Spec y los contratos vigentes.
---

# Context Pinning Skill

Asegura que los agentes siempre trabajen sobre la base de conocimiento actualizada del proyecto.

## Detección

- Este skill se considera **ACTIVO** para todos los agentes al inicio de una sesión o tras una compaction/rehidratación.

## Archivos Core en `.opencode-context`

El agente debe priorizar la lectura de:

- **Master Spec de Solución**: Si existe una carpeta `projects/` en el nivel superior, leer la spec macro en `../../docs/specs/master_spec.md`.
- **Master Spec del Proyecto**: `docs/specs/master_spec.md` (Fuente de verdad funcional consolidada del microservicio).
- **Contratos OpenAPI**: Ruta canónica declarada por el proyecto en shared context o spec. Ubicaciones válidas por defecto:
    - Spring Boot: `docs/api/openapi.yaml`, `src/main/resources/openapi.yaml`
    - FastAPI: Autogenerado desde el código; verificar `docs/api/openapi.yaml` si existe.
    - Node.js: `docs/api/openapi.yaml`
- **Incrementos Activos**: Cualquier spec en `docs/specs/increments/` que aún no haya sido consolidada.
- **Configuración de Build**: `build.gradle`/`pom.xml` (Java), `pyproject.toml` (Python), `package.json` (Node.js).
- **Contexto SDD activo**: `docs/specs/.working/<increment>-sdd-context.md`.
- **Task board activo**: `docs/specs/tasks/<increment>-task-board.md` cuando exista.

## Regla de Análisis de Cambio

Antes de modificar código, el agente DEBE:
1. Validar la tarea contra la `Master Spec` para entender el impacto global.
2. Si es una modificación, identificar la spec de incremento que originó la lógica actual para no romper reglas históricas.

## Prevención de Drift

- El agente debe alertar si detecta que el código que va a modificar no coincide con lo descrito en el contexto "pineado".
- No se debe asumir una ruta única de OpenAPI si el shared context declara otra ruta canónica existente. La ruta declarada debe verificarse leyendo el archivo real antes de marcar consistencia.
- Si un reporte viejo o resumen contradice archivos actuales, se marca como `superseded` y se usan los archivos actuales.

## Rehidratación tras Compaction

Después de una compaction o sesión resumida, Planner, Spec Validator, Task Decomposer y Executor deben rehidratar contexto desde disco: shared context, spec, OpenAPI, migraciones/config, task board y último reporte de validación. El resumen compacto del chat solo es una pista.

## Prohibiciones

- Prohibido modificar código sin haber leído la Master Spec primero.
- Prohibido asumir rutas de OpenAPI sin verificar el archivo real.
- Prohibido usar un reporte viejo que contradice archivos actuales sin marcarlo como `superseded`.