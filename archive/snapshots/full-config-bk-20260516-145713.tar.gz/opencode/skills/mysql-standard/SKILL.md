---
name: mysql-standard
description: Estándares y mejores prácticas para el diseño y gestión de bases de datos MySQL.
---

# Estándares MySQL

Guía para el uso eficiente de MySQL (InnoDB) en arquitecturas modernas, alineada con `flyway-migrations` y `jpa-stack`.

## Detección

- Si el proyecto usa MySQL como motor de base de datos (detectado por dependencias como `mysql-connector-java` en Maven/Gradle, `mysqlclient` en Python, o configuración de datasource), este skill se considera **ACTIVO**.

## Configuración y Almacenamiento

- **Engine**: Usar siempre `InnoDB`. Prohibido `MyISAM`.
- **Charset**: Usar `utf8mb4` con `utf8mb4_unicode_ci`. Prohibido `utf8` (es alias de utf8mb3 en MySQL 5.7, solo 3 bytes por carácter).
- **Collation**: `utf8mb4_unicode_ci` para plupartad de casos; usar `utf8mb4_0900_ai_ci` en MySQL 8+ si se require control fino de ordenamineto.
- **Naming**: `snake_case` para tablas, columnas, índices y constraints.
- **Prefijos de constraints**: `pk_` para primary keys, `fk_<tabla_origen>_<tabla_destino>` para foreign keys, `uk_<tabla>_<columna>` para unique, `chk_<tabla>_<condicion>` para checks, `idx_<tabla>_<columna>` para índices.

## Tipos de Datos

- **IDs**: Usar `INT UNSIGNED AUTO_INCREMENT` o `BIGINT UNSIGNED AUTO_INCREMENT`. Para IDs descentralizados, usar `CHAR(36)` para UUID o `BIGINT` con generador en aplicación.
- **Booleans**: Usar `TINYINT(1)` con convención `0/1`. MySQL no tiene booleano nativo.
- **JSON**: Usar tipo `JSON` nativo (MySQL 5.7+). Indexar campos JSON con virtual generated columns + índices.
- **Dates**: Preferir `DATETIME` para timestamps de negocio. Usar `TIMESTAMP` solo para campos de auditoría con zona horaria implícita. Tener en cuenta el límite de 2038 para `TIMESTAMP`.
- **Strings**: Usar `VARCHAR(n)` con límites explícitos. Evitar `TEXT` para columnas indexadas.

## Índices y Rendimiento

- **Primary Keys**: Siempre definir una clave primaria. Preferir `BIGINT UNSIGNED AUTO_INCREMENT`.
- **Composite Indexes**: El orden de las columnas debe seguir de mayor selectividad a menor, alineado con los patrones de consulta.
- **Prefix Indexes**: Evitar indexar columnas de texto largo completas; usar prefijos solo cuando sea estrictamente necesario.
- **EXPLAIN**: Usar `EXPLAIN` o `EXPLAIN ANALYZE` (MySQL 8+) para verificar el uso de índices.

## Integridad

- **Foreign Keys**: Definir siempre con nombres explícitos. Por defecto `ON DELETE RESTRICT`; usar `ON DELETE CASCADE` solo cuando sea explícitamente requerido por el dominio.
- **DDL No Transaccional**: La mayoría de sentencias DDL en MySQL no son transaccionales. Las migraciones deben diseñarse con esto en mente (ver `flyway-migrations`).

## Auditoría y Soft Delete

Obligatorio en toda tabla de negocio, alineado con `jpa-stack`:

- **Campos de Auditoría**:
    - `created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP`
    - `updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`
- **Soft Delete**:
    - `deleted TINYINT(1) NOT NULL DEFAULT 0`
    - Índice parcial obligatorio (MySQL 8+): `CREATE INDEX idx_<tabla>_active ON <tabla>(id) WHERE deleted = 0;` o composite index `(deleted, id)` en MySQL 5.7 sin filtered indexes.
- **Prohibido** usar `DELETE` físico en tablas de negocio. Usar `UPDATE SET deleted = 1` en su lugar.

## Prohibiciones

- Prohibido `MyISAM`.
- Prohibido charset `utf8` (usar `utf8mb4`).
- Prohibido `DELETE` físico en tablas de negocio.
- Prohibido crear tablas sin campos de auditoría y soft delete.
- Prohibido `TRIGGERs` y `STORED PROCEDUREs` complejos; preferir lógica en la aplicación.