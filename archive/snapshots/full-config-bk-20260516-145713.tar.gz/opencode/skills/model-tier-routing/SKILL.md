---
name: model-tier-routing
description: Política de escalamiento de modelos basada en la complejidad de la tarea para optimizar performance, costo y calidad del razonamiento.
---

# Model Tier Routing Skill

Define la política de escalamiento de modelos según el nivel de dificultad de la tarea. La fuente de verdad operativa para modelos específicos por agente es `/home/cristiansrc/Documentos/config-ai/active/opencode/agentes-y-modelos.md`.

## Detección

- Este skill se considera **ACTIVO** para la configuración y validación de agentes de OpenCode.

## Fuente de Verdad

- Los modelos específicos por agente están declarados en `agentes-y-modelos.md`.
- El modelo por defecto global de OpenCode está configurado en `opencode.json`.
- **Prohibido** cambiar modelos en archivos de agentes sin actualizar también `agentes-y-modelos.md` y `resumen-configuracion-ia.txt`.

## Escala de Complejidad

### Escala 1: Baja Complejidad
**Uso:** Mecanografía, tareas atómicas con specs 100% claras.
- Generación de boilerplate (getters/setters, constructors).
- Implementación de DTOs y Mappers simples.
- Tareas de documentación técnica básica.
- Corrección de errores de sintaxis simples.
- **Agentes**: `context-curator`, `documentation` (simple).

### Escala 2: Ejecución Rápida
**Uso:** Implementación mecánica desde specs y task boards validados.
- Cambios de código con alcance claro.
- Actualización de task board durante ejecución.
- Verificación con tests/comandos relevantes.
- **Agentes**: `executor`, `spec-remediator`.

### Escala 3: Complejidad Media/Alta
**Uso:** Implementación lógica, razonamiento arquitectónico local.
- Desarrollo de Casos de Uso (Application layer).
- Implementación de Adapters de persistencia o web.
- Refactorización de métodos y clases.
- Escritura de Unit Tests.
- Seguridad, refactor, test strategy y correcciones mecánicas de drift SDD.
- **Agentes**: `task-decomposer`, `reviewer`, `test-architect`, `refactor`.

### Escala 4: Alta Complejidad / Requerimientos / Diseño
**Uso:** Requirements Analyst, Planificación, Arquitectura y SDD.
- Creación de `requirements-brief.md`.
- Creación de Specs Técnicas (Planner).
- Diseño de Contratos OpenAPI complejos.
- Definición de Modelos de Datos y transaccionalidad.
- Análisis de impacto en sistemas distribuidos.
- **Agentes**: `requirements-analyst`, `planner`, `solution-architect`, `enterprise-architect`, `architect-executor`.

### Escala 5: Crítica / Validación
**Uso:** Seguridad, Auditoría y Verificación Final.
- Validación final de Specs críticas (Spec Validator).
- Validación final de producción (Final Validation).
- Resolución de problemas de alta concurrencia o race conditions.
- Auditoría de código sensible (Auth/Payment).
- **Agentes**: `spec-validator`, `security-reviewer`, `final-validation`.

## Regla Dinámica

Si un modelo de nivel inferior falla en resolver una tarea tras 2 intentos, el agente debe recomendar escalar al siguiente nivel de la pirámide. No cambiar modelos en archivos de agentes sin actualizar también la fuente de verdad (`agentes-y-modelos.md` y `resumen-configuracion-ia.txt`).

## Prohibiciones

- Prohibido cambiar modelos en archivos de agentes sin actualizar `agentes-y-modelos.md` y `resumen-configuracion-ia.txt`.
- Prohibido usar modelos de nivel inferior para tareas de Escala 4 o 5.