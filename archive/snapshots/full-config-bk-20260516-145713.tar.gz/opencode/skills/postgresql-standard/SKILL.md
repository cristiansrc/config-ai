---
name: postgresql-standard
description: Estándares y mejores prácticas para el diseño y gestión de bases de datos PostgreSQL.
---

# Estándares PostgreSQL

Guía para el uso eficiente de PostgreSQL en arquitecturas modernas, alineada con `flyway-migrations` y `jpa-stack`.

## Detección

- Si el proyecto usa PostgreSQL como motor de base de datos (detectado por dependencias como `postgresql` en Maven/Gradle, `psycopg2`/`asyncpg` en Python, o configuración de datasource), este skill se considera **ACTIVO**.

## Naming y Estructura

- **Naming**: `snake_case` para tablas, columnas, índices y constraints.
- **Prefijos de constraints**: `pk_` para primary keys, `fk_<tabla_origen>_<tabla_destino>` para foreign keys, `uk_<tabla>_<columna>` para unique, `chk_<tabla>_<condicion>` para checks, `idx_<tabla>_<columna>` para índices.
- **Schemas**: Organizar objetos en esquemas lógicos (ej: `public`, `audit`, `config`) si la base de datos es compartida por múltiples dominios.

## Tipos de Datos

- **IDs**: Usar `BIGSERIAL` para IDs autoincrementales o `UUID` (con extensión `uuid-ossp` o gen_random_uuid() en PG 13+) si se requiere descentralización.
- **Strings**: Preferir `VARCHAR(n)` con límites razonables para datos acotados. Usar `TEXT` solo para contenido sin límite.
- **JSON**: Usar siempre `JSONB` en lugar de `JSON` para mejor rendimiento y soporte de índices.
- **Booleans**: Usar tipo `BOOLEAN` nativo.
- **Timestamps**: Usar `TIMESTAMPTZ` (con zona horaria) en lugar de `TIMESTAMP` sin zona. Prohibido `TIMESTAMP WITHOUT TIME ZONE` para datos de negocio.
- **Money**: Prohibido el tipo `MONEY`. Usar `NUMERIC(p,s)` para valores monetarios.

## Índices y Rendimiento

- **B-Tree**: Por defecto para comparaciones de igualdad y rango.
- **GIN**: Obligatorio para columnas `JSONB` y arrays.
- **Partial Indexes**: Usar para filtrar nulos o estados comunes (ej: `WHERE deleted IS FALSE`).
- **Explain**: Usar `EXPLAIN ANALYZE` para diagnosticar queries lentas antes de añadir índices.

## Integridad

- **Constraints**: Definir siempre `NOT NULL` donde aplique. Usar `CHECK` para validaciones de dominio simples (ej: `price > 0`, `quantity >= 0`).
- **Enums**: Usar tipos `ENUM` nativos de Postgres para valores estáticos que raramente cambian. Para valores que pueden evolucionar, usar `VARCHAR` con `CHECK`.
- **Foreign Keys**: Definir siempre con nombre explícito. Por defecto `ON DELETE RESTRICT`; usar `ON DELETE CASCADE` solo cuando sea explícitamente requerido por el dominio.

## Auditoría y Soft Delete

Obligatorio en toda tabla de negocio, alineado con `jpa-stack`:

- **Campos de Auditoría**:
    - `created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP`
    - `updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP`
- **Soft Delete**:
    - `deleted BOOLEAN NOT NULL DEFAULT FALSE`
    - Índice parcial obligatorio: `CREATE INDEX idx_<tabla>_active ON <tabla>(id) WHERE deleted IS FALSE;`
- **Trigger de Actualización**:
    ```sql
    CREATE OR REPLACE FUNCTION update_updated_at_column()
    RETURNS TRIGGER AS $$
    BEGIN
        NEW.updated_at = CURRENT_TIMESTAMP;
        RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
    ```
- **Prohibido** usar `DELETE` físico en tablas de negocio. Usar `UPDATE SET deleted = TRUE` en su lugar.

## Prohibiciones

- Prohibido `TIMESTAMP WITHOUT TIME ZONE` para datos de negocio.
- Prohibido el tipo `MONEY`.
- Prohibido `DELETE` físico en tablas de negocio.
- Prohibido crear tablas sin campos de auditoría (`created_at`, `updated_at`) y soft delete (`deleted`).