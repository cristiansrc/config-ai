---
name: n8n-stack
description: Convenciones para el desarrollo y gestión de flujos en n8n (GitOps, modularidad, seguridad, observabilidad).
---

# Estándar n8n Workflow

Convenciones para el desarrollo y gestión de flujos de automatización en n8n con enfoque GitOps.

## Detección

- Si el repositorio contiene una carpeta `workflows/` con archivos `.json` de n8n, este skill se considera **ACTIVO**.

## Estructura de Archivos

- **Workflows**: `workflows/<dominio>-<nombre>.json` (Exportaciones de flujos versionados).
- **Templates**: `templates/<dominio>-<tipo>.json` (Workflows base reutilizables).
- **Config**: `config/environments.json` (Variables por entorno, sin secretos).
- **Docs**: `docs/workflows/` (Documentación de cada workflow: trigger, payload, credenciales referenciadas, retries, owner).

## Naming Conventions

- **Archivos**: `<dominio>-<accion>-<objeto>.json` en kebab-case (ej: `billing-generate-invoice.json`).
- **Nodos**: Nombrar cada nodo con formato `<tipo>-<proposito>` (ej: `http-request-get-user`, `if-validate-status`, `set-build-payload`).
- **Workflows**: El nombre interno del workflow debe coincidir con el nombre del archivo.

## GitOps

1. Todos los cambios en workflows deben exportarse como JSON y versionarse en el repositorio.
2. **Prohibido** editar workflows directamente en la UI de producción sin exportar el JSON actualizado al repo.
3. Usar el CLI de n8n o la API para importar/exportar workflows en CI/CD.
4. Los workflows de producción deben estar en la rama principal; los de desarrollo en ramas feature.

## Seguridad

- **Prohibido** guardar credenciales en los archivos JSON. Usar exclusivamente variables de entorno o el gestor de credenciales de n8n.
- **Prohibido** hardcodear tokens, API keys, passwords o cualquier secreto en nodos o expresiones.
- Referenciar credenciales por nombre, nunca por valor. El gestor de credenciales de n8n maneja la resolución.
- En `config/environments.json`, solo variables no sensibles (URLs, timeouts, umbrales). Los secretos van en el vault del entorno.

## Modularidad y Composición

- Preferir el nodo **Execute Workflow** para desacoplar lógicas complejas en sub-workflows reutilizables.
- Limitar cada workflow a una responsabilidad clara. Si un workflow tiene más de 20 nodos, evaluar si debe dividirse.
- Usar **Static Data** para compartir estado entre ejecuciones del mismo workflow (ej: última fecha procesada).
- Los templates son workflows base inmutables. Crear copias para personalizar; nunca modificar un template directamente.

## Manejo de Errores y Resiliencia

- **Error Trigger**: Configurar el nodo `Error Trigger` en workflows críticos para capturar fallos no manejados.
- **Retry en nodos HTTP**: Configurar reintentos con backoff en nodos de llamada HTTP (máximo 3 reintentos, backoff exponencial).
- **Continue On Fail**: Usar `continueOnFail=true` solo cuando el fallo del nodo es esperado y manejado downstream. Prohibido como solución permanente para errores desconocidos.
- **Timeouts**: Configurar timeout en nodos HTTP para evitar workflows colgados.

## Observabilidad y Trazabilidad

- Incluir `trace_id` en los payloads de entrada/salida para trazabilidad distribuida, alineado con el campo `trace_id` del error response estándar del stack activo.
- Usar el nodo **Set** para enriquecer el payload con metadatos de ejecución (`workflow_id`, `execution_id`, `timestamp`).
- Configurar logging de ejecuciones en entornos productivos.

## Pruebas

- **Workflows de test**: Crear workflows de prueba que llamen al workflow bajo test vía Execute Workflow con payloads controlados.
- **Webhook testing**: Para workflows triggered por webhook, usar herramientas como curl o Postman para verificar endpoints.
- **Validación de payload**: Verificar que los nodos de entrada validan la estructura del payload antes de procesar.

## Prohibiciones

- Prohibido guardar credenciales o secretos en archivos JSON.
- Prohibido editar workflows en producción sin exportar al repo.
- Prohibido `continueOnFail=true` como solución permanente para errores desconocidos.
- Prohibido workflows sin nodo de Error Trigger en entornos productivos.