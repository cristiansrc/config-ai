---
name: kafka-standard
description: Mejores prácticas para Apache Kafka (Particiones, Idempotencia, Schema Registry, EOS).
---

# Estándar Apache Kafka

Directrices para la implementación de sistemas basados en eventos usando Kafka, optimizando para alto rendimiento y consistencia dentro de Arquitectura Hexagonal.

## Detección

- Si se detectan dependencias como `spring-kafka`, `confluent-kafka-python`, `kafka-clients`, o configuraciones de brokers de Kafka, este skill se considera **ACTIVO**.

## Arquitectura Hexagonal

- Kafka es un **adaptador de infraestructura** (puerto de salida para producción, puerto de entrada para consumo).
- La lógica de negocio nunca depende directamente de Kafka; depende de interfaces/puertos abstractos.
- Los eventos entrantes se deserializan en el adaptador antes de pasar al caso de uso. Los eventos salientes se construyen en el adaptador a partir de eventos del dominio.

## Arquitectura y Diseño de Eventos

1. **Particiones y Escalabilidad**: Definir el número de particiones basado en el throughput esperado. Usar keys significativas para asegurar el orden de los mensajes relacionados en la misma partición.
2. **Schema Registry**: Uso obligatorio de Schema Registry (Confluent/Apicurio) con **Avro** o **Protobuf** para asegurar la evolución de contratos y compatibilidad. Prohibido publicar eventos sin schema registrado.
3. **Exactly-Once Semantics (EOS)**: Habilitar el soporte de transacciones de Kafka cuando se requiere consistencia exacta entre lectura de un tópico y escritura en otro.
4. **Transactional Outbox**: Para consistencia entre base de datos y Kafka, usar el patrón Outbox (CDC con Debezium o polling). Prohibido publicar directamente desde la lógica de negocio si la persistencia y la publicación deben ser atómicas.

## Configuración del Producer

- **Acks=all**: Obligatorio para garantizar que el mensaje se replique en todos los ISR.
- **Idempotent Producer**: Habilitar `enable.idempotence=true` para evitar duplicados en reintentos de red.
- **Compression**: Usar `snappy` o `zstd` para optimizar red y almacenamiento sin sacrificar CPU.
- **Retries**: Configurar `retries` al menos a `MAX_INT` con `max.in.flight.requests.per.connection=5` cuando idempotencia está habilitada.

## Configuración del Consumer

- **Consumer Groups**: Usar nombres descriptivos para los grupos de consumo (ej: `orders-billing-service-group`).
- **Auto-Offset Reset**: Preferir `earliest` para nuevos consumidores que no pueden perder datos históricos. Usar `latest` solo para consumidores tolerantes a pérdida.
- **Manual Commit**: En procesos críticos, gestionar el commit de offsets manualmente después de procesar exitosamente el mensaje.
- **Idempotency**: Obligatoria en el consumidor. Verificar por `message_id` o `event_id` antes de procesar.

## Resiliencia y Manejo de Errores

- **Dead Letter Topics (DLT)**: Mensajes que fallan tras reintentos deben enviarse a un tópico `<original-topic>-dlt` para inspección manual.
- **Error Handling Deserialization**: Configurar `ErrorHandlingDeserializer` en Spring para evitar "poison pills" que bloqueen el consumo.
- **Backoff**: Implementar reintentos con backoff exponencial. Prohibido reintentos infinitos sin DLT.

## Naming Conventions

- **Topics**: `<entorno>.<dominio>.<entidad>.<version>.<evento>` (ej: `prod.sales.order.v1.created`).
- **DLT**: `<entorno>.<dominio>.<entidad>.<version>.<evento>-dlt`
- **Consumer Groups**: `<dominio>.<servicio>.<proposito>-group`
- **Keys**: UUID de la entidad de negocio para garantizar orden por partición.

## Trazabilidad

- Incluir `trace_id` en los headers del evento para trazabilidad distribuida, alineado con el campo `trace_id` del error response estándar del stack activo.
- Incluir `message_id` como header para soporte de idempotencia y deduplicación.

## Pruebas

- **Herramientas**: Testcontainers para levantar Kafka + Schema Registry en tests de integración.
- **Tests de consumidor**: Verificar idempotencia, manejo de errores, commit de offsets y comportamiento con poison pills.
- **Tests de producer**: Verificar que los eventos se publican en el tópico correcto con la key y headers esperados.
- **Compatibilidad de Schema**: Verificar que los cambios de schema sean retrocompatibles usando las reglas de evolución de Schema Registry.

## Prohibiciones

- Prohibido publicar eventos sin schema registrado en Schema Registry.
- Prohibido `acks=0` o `acks=1` en producción.
- Prohibido publicar directamente desde lógica de negocio sin Outbox cuando se requiere atomicidad.
- Prohibido reintentos infinitos sin DLT.
- Prohibido `auto.offset.reset=latest` para consumidores que no pueden perder datos.