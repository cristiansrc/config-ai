---
name: keycloak-standard
description: Estándares y mejores prácticas para la configuración y gestión de identidad con Keycloak.
---

# Estándares Keycloak

Guía para la implementación segura y escalable de IAM (Identity and Access Management) con Keycloak. Para estándares generales de seguridad, ver `security-standards`.

## Detección

- Si el proyecto usa Keycloak como proveedor de identidad (detectado por dependencias como `keycloak-spring-boot-starter`, configuración de `issuer-uri`, o `keycloak.json`), este skill se considera **ACTIVO**.

## Arquitectura de Realms y Clientes

- **Realms**: Usar un Realm por aplicación o por entorno (Desarrollo, QA, Producción). Prohibido usar el realm `master` para aplicaciones.
- **Clientes**:
    - **Public**: Para SPAs y aplicaciones móviles (usan PKCE). Prohibido client secret en el frontend.
    - **Confidential**: Para aplicaciones Server-side (usan Client Secret).
    - **Bearer-only**: Para microservicios que solo validan tokens.

## Seguridad y Flujos de Autenticación

- **Flujo Estándar**: Usar siempre `Authorization Code Flow` con `PKCE`. Prohibido Resource Owner Password Credentials en producción.
- **Tokens**:
    - Access Token Lifespan: 5-15 minutos.
    - Refresh Tokens: Para sesiones largas, con rotación habilitada.
    - Prohibido tokens de larga duración (>1h) para APIs.
- **HTTPS**: Keycloak DEBE ejecutarse siempre tras HTTPS en producción. Prohibido HTTP.

## Roles y Autorización (RBAC/ABAC)

- **Roles de Realm**: Para permisos globales (ej: `admin`, `user`).
- **Roles de Cliente**: Para permisos específicos de una aplicación.
- **Grupos**: Usar para organizar usuarios jerárquicamente y asignar roles masivamente.
- **Client Scopes**: Usar para definir claims comunes (ej: `profile`, `email`, `roles`) que se comparten entre clientes.
- **Mappers**: Usar Protocol Mappers para añadir claims personalizados al token (ej: `organization_id`).

## Gestión de Usuarios y Federación

- **User Federation**: Conectar con LDAP/Active Directory para gestión de identidades corporativas.
- **Identity Brokering**: Usar para permitir login social (Google, GitHub) o protocolos OIDC/SAML externos.
- **Mappers**: Mapear claims personalizados (ej: `organization_id`, `department`) al token mediante Protocol Mappers.

## Configuración como Código

- Exportar la configuración del realm a JSON y versionarla en el repositorio.
- Usar `keycloak-config-cli` o Terraform para aprovisionar la configuración de Keycloak.
- Prohibido configuración manual en producción sin respaldo en código.

## Observabilidad

- Habilitar métricas y logs en formato JSON para integración con Prometheus/Grafana.
- Incluir `trace_id` en los eventos de autenticación para correlación con trazas distribuidas. Ver `observability-standard`.

## Pruebas

- Tests de integración contra Keycloak real (usar Testcontainers).
- Verificar: token válido, token expirado, issuer incorrecto, audience incorrecto, rol insuficiente.
- Verificar que el logout invalide la sesión correctamente.

## Prohibiciones

- Prohibido usar el realm `master` para aplicaciones.
- Prohibido Resource Owner Password Credentials en producción.
- Prohibido HTTP para Keycloak en producción.
- Prohibido configuración manual en producción sin respaldo en código.
- Prohibido client secret en código frontend (clientes Public).