---
name: context-curation
description: Estrategia de selección de contexto relevante para cada agente.
---

# Context Curation Strategy

Criterios para filtrar y proporcionar solo la información estrictamente necesaria a cada agente, optimizando el uso de la ventana de contexto y reduciendo el ruido.

## Detección

- Este skill se considera **ACTIVO** para todos los agentes al inicio de cualquier tarea.

## Principio General

Cada agente debe recibir solo el contexto necesario para su tarea. Evitar cargar archivos que no están directamente relacionados con el trabajo actual.

## Estrategias de Filtrado por Dominio

### Seguridad y Autenticación
- Archivos de configuración de seguridad (CORS, JWT, Roles).
- Lógica de Middlewares de autenticación.
- Esquemas de usuarios y permisos.
- **Skills relevantes**: `security-standards`, `keycloak-standard`.

### Persistencia y Base de Datos
- Definición de Entidades/Modelos.
- Archivos de migración y esquemas.
- Repositorios o DAOs específicos.
- **Skills relevantes**: `flyway-migrations`, skill de BD correspondiente, `jpa-stack` o `repository-dto-patterns`.

### Lógica de Negocio
- Servicios del dominio y entidades relacionadas.
- Especificaciones funcionales y reglas de negocio aplicables.
- Tests unitarios que describen el comportamiento esperado.
- **Skills relevantes**: `hexagonal-architecture`, `spec-driven-development`.

### Interfaz y Presentación
- Componentes visuales y hooks/servicios de estado asociados.
- Contratos de la API consumida.
- Estilos y assets relevantes para el componente en cuestión.
- **Skills relevantes**: `frontend-architecture`, `react-stack` o `angular-stack`.

## Archivos a Excluir del Contexto

- Archivos generados automáticamente (build output, compiled classes).
- Archivos de configuración de IDE (`.idea`, `.vscode`).
- Archivos de dependencias enteros (`package-lock.json`, `pom.xml` completo) - solo explicar la dependencia relevante.
- Logs y archivos temporales.
- Readme y documentación general (a menos que la tarea sea de documentación).

## Regla de Economía

- Si una tarea afecta un solo archivo, no cargar toda la carpeta.
- Si una tarea requiere entender una feature, cargar la spec del incremento + los archivos de implementación relacionados.
- Si una tarea requiere entender la arquitectura, cargar la Master Spec + el contrato OpenAPI + los archivos de configuración principales.

## Prohibiciones

- Prohibido cargar archivos completos de configuración de build cuando solo se necesita una dependencia.
- Prohibido cargar documentación general cuando la tarea es de implementación específica.