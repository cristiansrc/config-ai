---
name: rabbitmq-standard
description: Mejores prácticas para RabbitMQ en Arquitectura Hexagonal (Direct/Topic Exchanges, DLQ, Outbox, Idempotencia).
---

# Estándar RabbitMQ

Convenciones para el uso de RabbitMQ como broker de mensajería, asegurando resiliencia, trazabilidad y consistencia de datos dentro de Arquitectura Hexagonal.

## Detección

- Si se detectan dependencias como `spring-boot-starter-amqp` (Java), `pika`/`aio-pika` (Python), o archivos de configuración de RabbitMQ, este skill se considera **ACTIVO**.

## Arquitectura Hexagonal

- RabbitMQ es un **adaptador de infraestructura** (puerto de salida para publicación, puerto de entrada para consumo).
- La lógica de negocio nunca depende directamente de RabbitMQ; depende de interfaces/puertos abstractos.
- Los mensajes que entran al dominio se deserializan en el adaptador antes de pasar al caso de uso. Los mensajes que salen se construyen en el adaptador a partir de eventos del dominio.

## Patrones Obligatorios

1. **Transactional Outbox**: Para consistencia entre la base de datos y el broker. Los eventos se guardan en una tabla `outbox` en la misma transacción de negocio y un relay los publica a RabbitMQ. Prohibido publicar directamente desde la lógica de negocio si la persistencia y la publicación deben ser atómicas.
2. **Idempotent Consumer**: Cada consumidor debe verificar si ya procesó el mensaje (usando `message_id` en tabla de auditoría o Redis) antes de ejecutar lógica de negocio.
3. **Dead Letter Exchange (DLX)**: Configurar siempre un DLX y una DLQ para capturar mensajes que fallan después de agotar los reintentos.

## Configuración de Infraestructura

- **Exchanges**: Preferir `Topic Exchange` para máxima flexibilidad de enrutamiento o `Direct Exchange` para routing simple y predecible. Prohibido el default exchange en producción.
- **Durabilidad**: Colas y exchanges deben ser `durable=true`. Prohibido colas temporales para datos de negocio.
- **Persistencia**: Los mensajes deben marcarse como persistentes (`delivery_mode=2`).
- **Quorum Queues**: Usar Quorum Queues (requiere RabbitMQ 3.8+) para alta disponibilidad en entornos productivos. Las classic mirrored queues están deprecadas.

## Resiliencia y Manejo de Errores

- **Reintentos con Backoff**: Implementar reintentos exponenciales. Prohibido `requeue=true` inmediato si el fallo es persistente.
- **TTL de Mensajes**: Configurar tiempo de vida (`x-message-ttl`) para evitar que mensajes obsoletos bloqueen las colas.
- **Consumer Acknowledgements**: Usar `manual ack` para confirmar el procesamiento solo después de que la lógica de negocio y la persistencia local hayan tenido éxito.
- **Prefetch Count**: Configurar `prefetch_count` apropiado (default sugerido: 10) para evitar sobrecarga del consumidor.

## Naming Convention

- **Exchanges**: `<dominio>.<subdominio>.exchange` (ej: `orders.billing.exchange`)
- **Queues**: `<dominio>.<subdominio>.<proposito>.queue` (ej: `orders.billing.invoice-creation.queue`)
- **DLQ**: `<dominio>.<subdominio>.<proposito>.dlq`
- **Routing Keys**: `<dominio>.<entidad>.<accion>` (ej: `orders.order.created`)

## Serialización y Trazabilidad

- **Serialización**: Usar **JSON** (con Jackson en Java o Pydantic en Python) para interoperabilidad. Prohibido serialización nativa de Java.
- **Tracing**: Incluir `trace_id` y `message_id` en los headers de RabbitMQ para trazabilidad distribuida, alineado con el campo `trace_id` del error response estándar del stack activo.
- **Content Type**: Declarar `content_type` en las propiedades del mensaje (ej: `application/json`).

## Pruebas

- **Herramientas**: Testcontainers para levantar RabbitMQ en tests de integración.
- **Tests de consumidor**: Verificar idempotencia, manejo de errores y ack/nack.
- **Tests de publicador**: Verificar que los mensajes se publican en el exchange correcto con la routing key y headers esperados.

## Prohibiciones

- Prohibido el default exchange en producción.
- Prohibido colas temporales para datos de negocio.
- Prohibido publicar directamente desde lógica de negocio sin Outbox cuando se requiere atomicidad.
- Prohibido `requeue=true` inmediato para fallos persistentes.
- Prohibido serialización nativa de Java.