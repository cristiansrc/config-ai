---
name: documentation-standards
description: Estándares de documentación técnica y READMEs.
---

# Estándares de Documentación

Requisitos mínimos y formatos para la documentación técnica dentro del ecosistema de servicios.

## Detección

- Si el proyecto requiere documentación técnica (todos los proyectos), este skill se considera **ACTIVO**.

## Diagramas Mermaid

- Uso obligatorio de Mermaid.js para diagramas de arquitectura, secuencia y estados.
- Los diagramas deben estar integrados directamente en archivos Markdown.
- Mantener los diagramas actualizados con los cambios estructurales.
- Tipos de diagramas por contexto:
    - **Arquitectura**: `graph TD` para componentes y dependencias.
    - **Secuencia**: `sequenceDiagram` para flujos de interacción.
    - **Estados**: `stateDiagram-v2` para estados de entidades.

## Documentación de APIs

- Especificación obligatoria mediante OpenAPI (v3.1+). Ver `openapi-standard`.
- Descripción detallada de cada endpoint, parámetros y esquemas de respuesta.
- Inclusión de ejemplos de peticiones y respuestas exitosas/fallidas.
- Contrato OpenAPI en `docs/api/openapi.yaml`.

## README

Todo proyecto debe tener un `README.md` con:
1. **Descripción**: Propósito del proyecto.
2. **Prerrequisitos**: Versiones de lenguajes, herramientas y servicios dependientes.
3. **Instalación**: Pasos secuenciales para configurar el entorno local.
4. **Ejecución**: Comandos para iniciar el servicio.
5. **Tests**: Comandos para ejecutar tests unitarios, de integración y E2E.
6. **Variables de Entorno**: Referencia al archivo `.env.example` con descripción de cada variable.

## Variables de Entorno

- Documentar todas las variables necesarias en `.env.example`.
- Descripción del propósito de cada variable y sus posibles valores.
- Clasificación por entorno: Desarrollo, Staging, Producción.
- **Prohibido** incluir valores reales en `.env.example`. Solo placeholders descriptivos.

## ADR (Architecture Decision Records)

- Para decisiones arquitectónicas significativas, crear un ADR en `docs/adr/`.
- Formato: `NNNN-titulo.md` con contexto, decisión y consecuencias.
- Los ADRs son inmutables una vez creados; si una decisión cambia, crear un nuevo ADR que lo reemplaza.

## Comportamiento Obligatorio

1. Los diagramas deben estar en Markdown con Mermaid, no en imágenes externas.
2. El contrato OpenAPI debe estar en `docs/api/openapi.yaml`.
3. Toda variable de entorno debe estar documentada en `.env.example`.

## Prohibiciones

- Prohibido documentación en imágenes externas cuando Mermaid puede representarla.
- Prohibido valores reales en `.env.example`.
- Prohibido ADRs modificados; crear uno nuevo para cambios.