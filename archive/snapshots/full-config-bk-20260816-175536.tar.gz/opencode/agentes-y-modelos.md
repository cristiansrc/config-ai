# Agentes y Modelos OpenCode

Ultima actualizacion: 2026-08-16 (Post-auditoria de modelos - DeepSeek retirado, MiMo agregado)

Fuente activa:
- Configuracion: `/home/cristiansrc/.config/opencode/opencode.jsonc`
- Agentes: `/home/cristiansrc/.config/opencode/agents/`
- Skills: `/home/cristiansrc/.config/opencode/skills/`
- Backup de agentes: `/home/cristiansrc/Documentos/config-ai/active/opencode/agents/`
- Backup de skills: `/home/cristiansrc/Documentos/config-ai/active/opencode/skills/`

Regla de mantenimiento:
- Cualquier cambio en agentes, modelos, permisos o skills debe actualizar este archivo y `/home/cristiansrc/Documentos/config-ai/resumen-configuracion-ia.txt` en la misma sesion.
- Idioma obligatorio: Todas las respuestas e interacciones de los agentes con el usuario deben ser en ESPANOL.
- Politica de idioma de agentes: La definicion operativa, responsabilidades, reglas y guias de cada agente deben estar en ESPANOL. Se mantienen en INGLES los nombres de agentes/skills, estados canonicos, headings, rutas, comandos, campos de protocolo y tokens exactos como `ready`, `blocked`, `validated-not-executed`, `## Spec Validator Approval` o `Blocked: ...`.
- Contratos de error por stack: Spring Boot Java usa `springboot-java-rest-error-response-standards`, Spring Boot Kotlin usa `springboot-kotlin-rest-error-response-standards` y FastAPI usa `fastapi-rest-error-response-standards`.
- Convenciones de stack: `nodejs-stack`, `python-stack`, `fastapi-stack`, `springboot-stack`, `java-stack`, `kotlin-stack` y `golang-stack` son la fuente de verdad para reglas tecnicas de cada runtime.
- Estandar de Testing Funcional: `functional-testing-standard` define la estrategia de planeacion, reporte y correccion de pruebas UI/E2E en frontends utilizando Puppeteer MCP o frameworks locales.
- Cambio operativo vigente: Planner puede crear o actualizar unicamente el `.gitignore` raiz del repositorio activo ademas de specs/OpenAPI, para excluir artefactos no versionables de specs y codigo generado sin ocultar artefactos canonicos.
- Cambio operativo vigente: Spec Remediator debe invocar validaciones solo mediante `spec-validator` con `opencode-go/qwen3.7-plus`; cualquier validacion ejecutada con otro modelo debe bloquearse como `Blocked: wrong validator model`.
- Estandares de Calidad y Pruebas Avanzadas: `code-quality-and-sonarqube` (SonarScanner, SpotBugs, Ruff, golangci-lint, script ./verify-code.sh), `performance-testing-k6` (k6 load testing, p95 < 200ms), `eval-ops-agent-benchmarks` (benchmarks de regresion de agentes), `zero-downtime-migrations` (Expand/Contract DB), `root-cause-analysis` (RCA protocol), `api-governance-linter` (OpenAPI breaking changes) y `testing-strategy` (TDD Red-Green-Refactor, ArchUnit, Concurrencia).
- Estructura de Solution Workspace (OPCIONAL): La pertenencia a un Solution Workspace esta condicionada a que la carpeta padre del proyecto se llame exactamente `projects/`.
  - Si el padre NO es `projects/`: El proyecto es STANDALONE; no requiere ni debe tener documentacion enterprise ni Master Spec global.
  - Si el padre ES `projects/`: El proyecto es parte de una solucion. Los agentes deben usar esta carpeta como frontera para distinguir contexto LOCAL de GLOBAL.
  - Gestion de Git (Enterprise Architect): El `enterprise-architect` debe configurar el `.gitignore` de la raiz del Workspace para ignorar el contenido de `projects/` (`projects/**`), ya que los proyectos se versionan independientemente.
  - Inicializacion: La carpeta `projects/` debe ser creada automaticamente por el agente al detectar que se inicia un flujo de Solution Workspace si aun no existe.
- Gestion de Paquetes JS/TS: Queda ESTRICTAMENTE PROHIBIDO el uso de `npm` para cualquier tarea (Node, React, Angular, etc.). Se debe utilizar exclusivamente `pnpm`. Esto responde a requerimientos de seguridad y eficiencia. Los agentes deben fallar si detectan un `package-lock.json` y proponer la migracion a `pnpm-lock.yaml`. Se deben seguir las mejores practicas de pnpm para la gestion de dependencias.
- Soporte de Contexto mediante Grafos (Graphify): Para optimizar el contexto de los agentes, reducir el consumo de tokens y asegurar la trazabilidad arquitectonica, se utiliza Graphify en los proyectos compatibles. Los agentes deben consultar y actualizar el grafo de conocimiento segun define la skill `graphify`.
- Aislamiento Operativo de Git: Queda ESTRICTAMENTE PROHIBIDO para todos los agentes de desarrollo, pruebas o documentacion ejecutar cualquier comando Git (`git add`, `git commit`, `git push`, `git checkout`, etc.) en la terminal. Toda operacion relacionada con Git debe delegarse de forma exclusiva al agente `git-executor`.

---

## BLOQUEO DE MODELOS (Agosto 2026)

Los siguientes modelos estan BLOQUEADOS y NO deben usarse en ningun agente:

| Modelo | Razon | Fuente |
|--------|-------|--------|
| `opencode-go/deepseek-v4-flash` | TCP drop, 403, 400, cuelgues. ROTO desde Aug 4 | GitHub #40465, #40485, #41306 |
| `opencode/deepseek-v4-flash-free` | 503 cola llena, bucles infinitos, resp vacias | GitHub #40254, #30443 |
| `opencode-go/deepseek-v4-pro` | Sirve V3.2 en vez de V4 real. No confiable | GitHub #40409 |
| `opencode/deepseek-v4-pro` | Requiere opt-in China. ZDR incierto | GitHub #39845 |

---

## Estado de Modelos Go (Agosto 2026)

| Modelo | Req/5h | Estabilidad | Costo 1M in/out |
|--------|--------|-------------|-----------------|
| qwen3.7-plus | 4,300 | 70% (timeouts CF 524) | $0.40/$1.60 |
| glm-5.2 | 880 | 95%+ | $1.40/$4.40 |
| mimo-v2.5 | 30,100 | 90%+ | $0.14/$0.28 |
| kimi-k2.7-code | 1,350 | Sin datos | $0.95/$4.00 |
| minimax-m3 | 3,200 | Sin datos | $0.30/$1.20 |

Perfil LM Studio persistente:
- `lmstudio/qwen/qwen3.6-35b-a3b`: context length `152563`, GPU offload ratio `26/64` capas, K/V cache `Q4_0`. OpenCode declara el mismo limite de contexto para que no intente usar el valor anterior.

---

## Tabla de Agentes y Modelos (Actualizada 2026-08-16)

| Agente | Modelo | Proveedor | Editar | Bash | Descripcion |
|--------|--------|-----------|--------|------|-------------|
| api-governance-agent | opencode-go/glm-5.2 | Go | deny | allow | Audita contratos OpenAPI buscando Breaking Changes, backward compatibility y reglas semver. |
| architect-executor | opencode-go/qwen3.7-plus | Go | allow | allow | Implementa tareas complejas y arquitectura local con razonamiento denso cuando NO existe especificacion SDD completa. |
| bug-diagnostician | opencode-go/glm-5.2 | Go | deny | allow | Realiza analisis de causa raiz (RCA) e inspeccion de logs/stack traces antes de implementar correcciones. |
| context-curator | opencode-go/qwen3.7-plus | Go | deny | deny | Gestiona la ventana de contexto (Temp 0.10) y reduce ruido siguiendo `context-curation` y `context-pinning`. |
| database-architect | opencode-go/qwen3.7-plus | Go | allow | allow | Disena esquemas DB relacionales, migraciones Flyway/Liquibase e indices sin tiempo de inactividad (Zero-Downtime DB Migrations). |
| devops-architect | opencode-go/qwen3.7-plus | Go | allow | allow | Especialista en Infraestructura como Codigo y CI/CD siguiendo `docker-standard` y `observability-standard`. |
| documentation | opencode-go/qwen3.7-plus | Go | allow | deny | Gestiona el ciclo de vida de la documentacion siguiendo `documentation-lifecycle` y `documentation-standards`. |
| enterprise-architect | opencode-go/qwen3.7-plus | Go | allow | deny | Define el System Landscape, fronteras de microservicios y flujos globales siguiendo `enterprise-architecture-standard`. **Fallback: glm-5.2** |
| enterprise-spec-validator | opencode-go/qwen3.7-plus | Go | allow | deny | Valida la coherencia global del Solution Workspace, contratos de integracion y deuda tecnica global siguiendo `workspace-coordination`. |
| executor | opencode-go/qwen3.7-plus | Go | allow | allow | Implementa codigo verificado (Temp 0.15) cuando EXISTE especificacion SDD validada. **Alt: kimi-k2.7-code** |
| final-validation | opencode-go/glm-5.2 | Go | deny | allow | Garantiza la calidad final y cobertura minima siguiendo `testing-strategy` y `pre-flight-check`. |
| functional-tester-agent | opencode-go/qwen3.7-plus | Go | allow | allow | Disena plan, ejecuta y valida pruebas funcionales y UI/E2E en frontends con Puppeteer MCP. |
| git-executor | **opencode-go/mimo-v2.5** | Go | allow | allow | Centraliza de manera exclusiva todas las interacciones del repositorio con Git (ramas, commits, checkout, pushes). **Cambiado de qwen3.7-plus a mimo-v2.5 para ahorrar quota Go.** |
| master-orchestrator | opencode/kimi-k3 | **Zen** | deny | allow | Agente Maestro / Orquestador Contextual. Mantiene el contexto de la spec y delega tareas a subagentes de forma estructurada. **Zen pay-as-you-go. Usar con moderacion.** |
| planner | opencode-go/glm-5.2 | Go | allow | deny | Planifica incrementos SDD y disena contratos. Consulta a `solution-architect` para decisiones de patrones complejos. |
| refactor | opencode-go/qwen3.7-plus | Go | allow | allow | Refactoriza codigo existente siguiendo `refactor-patterns` y `refactor-hexagonal-bridge`. |
| requirements-analyst | opencode-go/glm-5.2 | Go | allow | deny | Realiza el levantamiento de requerimientos funcionales siguiendo `requirements-gathering`. |
| reviewer | opencode-go/glm-5.2 | Go | deny | allow | Audita el codigo generado buscando drift y bugs siguiendo `code-review-checklist`. |
| security-reviewer | opencode-go/glm-5.2 | Go | deny | allow | Valida la postura de seguridad siguiendo `security-standards` y `keycloak-standard`. |
| solution-architect | opencode-go/qwen3.7-plus | Go | allow | deny | Elige patrones de diseno siguiendo `design-patterns-standard`. Colabora con `enterprise-architect`. **Fallback: glm-5.2** |
| spec-remediator | opencode-go/qwen3.7-plus | Go | allow | deny | Corrige hallazgos de validacion de forma iterativa siguiendo `spec-remediation`. |
| spec-validator | opencode-go/qwen3.7-plus | Go | allow limitado | deny | Valida la consistencia de los artefactos SDD siguiendo `spec-driven-development`. |
| task-decomposer | opencode-go/qwen3.7-plus | Go | allow | deny | Descompone especificaciones en tareas atomicas siguiendo los contratos de `spec-driven-development`. |
| test-architect | opencode-go/qwen3.7-plus | Go | allow | allow | Disena la estrategia de pruebas y genera casos de test siguiendo `testing-strategy`. |
| hyprmind-orchestrator | opencode/kimi-k3 | **Zen** | allow | allow | (V.I.E.R.N.E.S.) Orquestador conversacional principal de tu sistema y manejador del workspace. **Zen pay-as-you-go.** |
| hyprmind-vision-analyst | opencode-go/qwen3.7-plus | Go | deny | deny | El "Ojo Bionico" que procesa y explica tus capturas de pantalla o interfaces visuales. |
| hyprmind-deep-thinker | opencode-go/qwen3.7-plus | Go | deny | deny | Filosofo y motor de razonamiento denso para discusiones complejas o diseno abstracto. |

---

## Resumen de Cambios (2026-08-16)

1. **git-executor**: `opencode-go/qwen3.7-plus` → `opencode-go/mimo-v2.5` (ahorro de quota Go, operaciones Git son mecanicas)
2. **model-tier-routing SKILL.md**: Reescritura completa con realidad actual de modelos, fallbacks y bloqueos
3. **DeepSeek V4 Flash/Pro**: Bloqueados en Go y Zen por fallos confirmados por la comunidad
4. **Qwen 3.7 Plus**: Mantenido como modelo principal para la mayoria de agentes (mejor costo/beneficio). Inestabilidad ~70% documentada.
5. **Kimi K3 en Zen**: Advertencia de costo agregada. Usar solo para orquestacion.
6. **MiMo V2.5**: Agregado como modelo ligero para tareas simples.
7. **Kimi K2.7 Code**: Documentado como alternativa de coding cuando Qwen falle.

---

## Politica de Fallback Rapida

Si Qwen 3.7 Plus falla 3+ veces consecutivas:
- **Ejecucion de codigo**: Cambiar a `opencode-go/kimi-k2.7-code`
- **Validacion/Arquitectura**: Cambiar a `opencode-go/glm-5.2`
- **Tareas ligeras**: Cambiar a `opencode-go/mimo-v2.5`

Si Kimi K3 (Zen) esta consumiendo demasiado credito:
- Evaluar si la tarea de orquestacion puede hacerla `opencode-go/glm-5.2`
