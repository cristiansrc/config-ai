# Agentes y Modelos Gemini CLI

Ultima actualizacion: 2026-05-22

Fuente activa:
- Agentes: `/home/cristiansrc/Documentos/config-ai/gemini/agents/`
- Skills: `/home/cristiansrc/Documentos/config-ai/gemini/skills/`
- Backup: `/home/cristiansrc/Documentos/config-ai/gemini/backups/`

| Agente | Modelo | Editar | Bash | Descripcion |
|---|---|---:|---:|---|
| commander (DEFAULT) | opencode-zen/deepseek-v4-flash-free | allow | allow | Agente principal para gestion del sistema operativo, terminal y tareas diarias. |
| architect-executor | opencode-zen/deepseek-v4-flash-free | allow | allow | Arquitectura y ejecucion compleja. |
| context-curator | opencode-zen/deepseek-v4-flash-free | deny | deny | Curacion de contexto eficiente. |
| documentation | opencode-zen/deepseek-v4-flash-free | allow | deny | Generacion de documentacion. |
| executor | opencode-zen/deepseek-v4-flash-free | allow | allow | Implementacion de codigo. |
| final-validation | opencode-zen/deepseek-v4-flash-free | deny | allow | Validacion final de calidad. |
| planner | opencode-zen/deepseek-v4-flash-free | allow | deny | Planificacion y specs SDD. |
| refactor | opencode-zen/deepseek-v4-flash-free | allow | allow | Refactorizacion de codigo. |
| requirements-analyst | opencode-zen/deepseek-v4-flash-free | allow | deny | Analisis de requerimientos iniciales. |
| reviewer | opencode-zen/deepseek-v4-flash-free | deny | allow | Revision de codigo y calidad. |
| security-reviewer | opencode-zen/deepseek-v4-flash-free | deny | allow | Auditoria de seguridad. |
| spec-remediator | opencode-zen/deepseek-v4-flash-free | allow | deny | Correccion automatica de specs. |
| spec-validator | opencode-zen/deepseek-v4-flash-free | allow | deny | Validacion de specs SDD. |
| task-decomposer | opencode-zen/deepseek-v4-flash-free | allow | deny | Descomposicion de tareas. |
| test-architect | opencode-zen/deepseek-v4-flash-free | allow | allow | Diseno de pruebas automatizadas. |
| functional-test-planner | opencode-zen/deepseek-v4-flash-free | allow | deny | Analisis de specs y diseno de planes de pruebas funcionales. |
| functional-tester-agent | opencode-zen/deepseek-v4-flash-free | allow | allow | Diseno, ejecucion y validacion de pruebas funcionales y UI/E2E en frontends. |
