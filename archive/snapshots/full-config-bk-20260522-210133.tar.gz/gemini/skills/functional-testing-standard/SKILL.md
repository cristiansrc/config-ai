---
name: functional-testing-standard
description: Estándares y flujo de trabajo para el diseño, ejecución y corrección de pruebas funcionales en Frontends usando Puppeteer MCP o frameworks locales del workspace.
---

# Functional Testing Standard

Esta skill define el estándar operativo para realizar pruebas funcionales de caja negra y flujos de usuario (E2E) en frontends. Establece las responsabilidades para la detección de bugs visuales o de flujo, el formato del reporte de errores y el proceso de remediación en el workspace.

## 1. Estrategia de Ejecución de Pruebas

El agente de QA o pruebas funcionales debe elegir entre dos enfoques principales según la configuración y el estado del proyecto:

### A. Pruebas Interactivas vía MCP (Puppeteer)
Útil para validación rápida en caliente, exploración visual y flujos que no cuenten con una suite automatizada.
1. **Lanzamiento de App**: Levantar el servidor de desarrollo del frontend en segundo plano si no está encendido:
   ```bash
   pnpm run dev
   ```
2. **Navegación e Interacción**: Usar las herramientas del MCP `puppeteer` (`puppeteer_navigate`, `puppeteer_click`, `puppeteer_fill`, `puppeteer_evaluate`, etc.) para recorrer la aplicación.
3. **Verificación Visual**: Tomar capturas de pantalla (`puppeteer_screenshot`) en momentos clave y ante cualquier error observado.
4. **Verificación de Consola**: Inspeccionar errores de consola JS o de carga de red (drifts con OpenAPI/API caída).

### B. Pruebas Automatizadas del Workspace (Playwright / Cypress)
Útil para regresión, ejecución en pipelines y validación masiva basada en código de tests.
1. **Instalación de Dependencias**: Si el proyecto requiere herramientas de testing, agregarlas exclusivamente mediante `pnpm` (no usar `npm` ni `yarn`):
   ```bash
   pnpm add -D @playwright/test
   pnpm exec playwright install
   ```
2. **Ejecución**: Correr los comandos del framework local:
   ```bash
   pnpm test:functional
   # o bien
   pnpm playwright test
   ```

---

## 2. Estructura del Reporte de Fallos

Cuando se detecten errores funcionales, el agente DEBE crear o actualizar el archivo de reporte en el workspace:
`docs/functional-testing/functional-test-report.md`

El formato exacto debe ser el siguiente:

```markdown
# Reporte de Pruebas Funcionales - Frontend

**Última Actualización:** [AAAA-MM-DD HH:MM:SS]
**Estado Global:** [FAILED / PASSED]
**Ejecutor:** [Nombre del Agente]

---

## 1. Resumen de Ejecución
- **Total Tests Ejecutados:** X
- **Pasados:** Y
- **Fallados:** Z
- **Entorno de Red:** [Localhost / Staging / Mocked]

---

## 2. Errores Detectados

### [ID_ERROR] - [Nombre descriptivo del error]
- **Componente / Ruta:** `/ruta-de-la-app` o `src/components/ComponentName`
- **Comportamiento Esperado:** Descripción clara de lo que debería hacer el frontend.
- **Comportamiento Actual:** Descripción detallada del fallo.
- **Evidencia (Consola / Red / UI):**
  - Logs de error en consola.
  - Screenshots guardados en `docs/functional-testing/screenshots/error-id.png` (si aplica).
- **Causa Raíz Sospechada:** [Drift de API, error de binding, estilo roto, validación incompleta, etc.]
- **Estado:** [TODO / IN_PROGRESS / FIXED / BLOCKED]

---

## 3. Plan de Remediación
- **Acciones sugeridas:** [ej. Corregir validación del formulario en el frontend, actualizar tipado con el contrato OpenAPI, etc.]
- **Asignado a:** [functional-tester-agent / executor / planner / usuario]
```

---

## 3. Ciclo de Corrección y Validación (Remediación)

1. **Triage y Clasificación**:
   - **Fix Mecánico (Frontend)**: Si el fallo reside puramente en el cliente (ej. clase CSS mal puesta, propiedad undefined en renderizado, evento onClick incorrecto, binding roto), el propio `functional-tester-agent` o `executor` puede proceder a repararlo.
   - **Bloqueo (Backend / Diseño)**: Si la resolución implica cambiar el contrato de API (OpenAPI), reestructurar la lógica del backend o tomar decisiones críticas de producto, detener el flujo, marcar el error como `BLOCKED` con la justificación y enrutar al `planner` o al usuario.

2. **Aplicación del Fix**:
   - Modificar los archivos respetando las convenciones del stack (`react-stack`, `angular-stack`, `frontend-architecture`).
   - Mantener el diseño limpio y no introducir sleeps arbitrarios en el código.

3. **Re-validación**:
   - Volver a levantar el dev server si es necesario.
   - Ejecutar la suite de tests o el flujo manual de Puppeteer de nuevo.
   - Si pasa con éxito, actualizar el estado del error en el reporte a `FIXED` y el **Estado Global** a `PASSED`.

---

## 4. Criterios de Aceptación del Entregable
Se considerará aprobada la tarea de pruebas funcionales cuando:
1. El archivo `docs/functional-testing/functional-test-report.md` exista en el workspace.
2. Todos los errores identificados tengan un estado claro (`FIXED` o `BLOCKED` con reporte respectivo).
3. Si el estado global es `PASSED`, la aplicación no debe presentar errores de JS en la consola durante los flujos críticos.
4. El servidor de desarrollo del frontend se apague adecuadamente al finalizar el trabajo (si fue iniciado por el agente).
