# Agentes y Modelos Gemini CLI

Ultima actualizacion: 2026-05-22

Fuente activa:
- Agentes: `/home/cristiansrc/Documentos/config-ai/gemini/agents/`
- Skills: `/home/cristiansrc/Documentos/config-ai/gemini/skills/`
- Backup: `/home/cristiansrc/Documentos/config-ai/gemini/backups/`

| Agente | Modelo | Editar | Bash | Descripcion |
|---|---|---:|---:|---|
| commander (DEFAULT) | lmstudio/google/gemma-4-e4b | allow | allow | Agente principal para gestion del sistema operativo, terminal y tareas diarias. |
| architect-executor | lmstudio/google/gemma-4-12b | allow | allow | Arquitectura y ejecucion compleja. |
| context-curator | lmstudio/google/gemma-4-e4b | deny | deny | Curacion de contexto eficiente. |
| documentation | lmstudio/google/gemma-4-e4b | allow | deny | Generacion de documentacion. |
| executor | lmstudio/google/gemma-4-e4b | allow | allow | Implementacion de codigo. |
| final-validation | lmstudio/google/gemma-4-12b | deny | allow | Validacion final de calidad. |
| planner | lmstudio/google/gemma-4-12b | allow | deny | Planificacion y specs SDD. |
| refactor | lmstudio/google/gemma-4-12b | allow | allow | Refactorizacion de codigo. |
| requirements-analyst | lmstudio/google/gemma-4-12b | allow | deny | Analisis de requerimientos iniciales. |
| reviewer | lmstudio/google/gemma-4-12b | deny | allow | Revision de codigo y calidad. |
| security-reviewer | lmstudio/google/gemma-4-12b | deny | allow | Auditoria de seguridad. |
| spec-remediator | lmstudio/google/gemma-4-e4b | allow | deny | Correccion automatica de specs. |
| spec-validator | lmstudio/google/gemma-4-12b | allow | deny | Validacion de specs SDD. |
| task-decomposer | lmstudio/google/gemma-4-e4b | allow | deny | Descomposicion de tareas. |
| test-architect | lmstudio/google/gemma-4-e4b | allow | allow | Diseno de pruebas automatizadas. |
| functional-test-planner | lmstudio/google/gemma-4-12b | allow | deny | Analisis de specs y diseno de planes de pruebas funcionales. |
| functional-tester-agent | lmstudio/google/gemma-4-12b | allow | allow | Diseno, ejecucion y validacion de pruebas funcionales y UI/E2E en frontends. |
