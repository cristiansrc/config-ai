# Agentes y Modelos Gemini CLI

Ultima actualizacion: 2026-05-12

Fuente activa:
- Agentes: `/home/cristiansrc/Documentos/config-ai/gemini/agents/`
- Skills: `/home/cristiansrc/Documentos/config-ai/gemini/skills/`
- Backup: `/home/cristiansrc/Documentos/config-ai/gemini/backups/`

| Agente | Modelo | Editar | Bash | Descripcion |
|---|---|---:|---:|---|
| commander (DEFAULT) | gemini-1.5-pro | allow | allow | Agente principal para gestion del sistema operativo, terminal y tareas diarias. |
| architect-executor | gemini-1.5-pro | allow | allow | Arquitectura y ejecucion compleja. |
| context-curator | gemini-1.5-flash | deny | deny | Curacion de contexto eficiente. |
| documentation | gemini-1.5-flash | allow | deny | Generacion de documentacion. |
| executor | gemini-1.5-pro | allow | allow | Implementacion de codigo. |
| final-validation | gemini-1.5-pro | deny | allow | Validacion final de calidad. |
| planner | gemini-1.5-pro | allow | deny | Planificacion y specs SDD. |
| refactor | gemini-1.5-pro | allow | allow | Refactorizacion de codigo. |
| requirements-analyst | gemini-1.5-pro | allow | deny | Analisis de requerimientos iniciales. |
| reviewer | gemini-1.5-pro | deny | allow | Revision de codigo y calidad. |
| security-reviewer | gemini-1.5-pro | deny | allow | Auditoria de seguridad. |
| spec-remediator | gemini-1.5-pro | allow | deny | Correccion automatica de specs. |
| spec-validator | gemini-1.5-pro | allow | deny | Validacion de specs SDD. |
| task-decomposer | gemini-1.5-pro | allow | deny | Descomposicion de tareas. |
| test-architect | gemini-1.5-pro | allow | allow | Diseno de pruebas automatizadas. |
